import http.client
import json
import os

conn = http.client.HTTPSConnection("google.serper.dev")
payload = json.dumps({
  "q": "site:youtube.com (\"XIAO ESP32\" OR \"XIAO ESP32S3\" OR \"XIAO ESP32C3\" OR \"XIAO ESP32C6\" OR \"XIAO ESP32C5\" OR \"XIAO nRF52840\" OR \"XIAO nRF54L15\" OR \"XIAO BLE\" OR \"XIAO MG24\" OR \"XIAO RP2040\"OR \"XIAO RP2350\" OR \"XIAO SAMD21\" OR \"XIAO RA4M1\")",
  "tbs": "qdr:w,dur:m",
  "n_results": 20
})
headers = {
  'X-API-KEY': '14b27afd12c93ade7c9e81bf4ffb69eff092d0f5',
  'Content-Type': 'application/json'
}
conn.request("POST", "/videos", payload, headers)
res = conn.getresponse()
data = res.read()
print(data.decode("utf-8"))
