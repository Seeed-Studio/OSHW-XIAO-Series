# XIAO Community Projects Weekly

*19 projects · May 11, 2026*

*Discover what makers are building with Seeed Studio XIAO development boards. This week: 19 new community projects spanning Robotics, Smart Home, AI Gadget, Wearables, Tools & Accessories, and IoT.*

---

## RobotDuck Head ESP32 by AI-FanGe

A playful **robot duck head** that responds to faces with animated expressions and speaks using text-to-speech. Built on the **XIAO ESP32-S3 Sense**, it uses **Python** for the facial recognition pipeline and runs the expression engine on the XIAO board itself.

**Hardware Recommendation**
- **XIAO:** [Seeed Studio XIAO ESP32-S3 Sense](https://www.seeedstudio.com/XIAO-ESP32S3-Sense-p-5639.html)
- **Expansion:** null
- **Grove Ecosystem:** null

[View project](https://github.com/AI-FanGe/RobotDuck_Head_Esp32)

---

## How to make 3D Printed Spy Car at home | Spy Camera Car | ESP32 CAM | DIY Robot by Simple Circuits

![3D Printed Spy Car](https://i.ytimg.com/vi/Du1UvHnD-ZM/maxresdefault.jpg)

A fully **3D printed WiFi FPV spy car** built around the **XIAO ESP32-S3**. The tiny board handles both live video streaming and motor control simultaneously, eliminating the need for separate controllers. The chassis is designed for durability while keeping the total build cost low.

**Hardware Recommendation**
- **XIAO:** [Seeed Studio XIAO ESP32-S3](https://www.seeedstudio.com/XIAO-ESP32S3-p-5627.html)
- **Expansion:** null
- **Grove Ecosystem:** null

[View project](https://www.youtube.com/watch?v=Du1UvHnD-ZM)

---

## ESP32 Guide 2026 by DroneBot Workshop

![ESP32 Guide 2026](https://i.ytimg.com/vi/CfIjInYch7U/maxresdefault.jpg)

The most comprehensive **ESP32 board selection guide** for 2026, updated to cover every variant currently available — including the full **XIAO ESP32 family** (ESP32-S3, ESP32-C5, ESP32-C3, ESP32-C6, ESP32-S3 Sense). DroneBot Workshop walks through each chip's strengths, weakness, and ideal use cases so you can pick the right board without the guesswork.

**Hardware Recommendation**
- **XIAO:** [Seeed Studio XIAO ESP32-S3](https://www.seeedstudio.com/XIAO-ESP32S3-p-5627.html) ， [Seeed Studio XIAO ESP32-C5](https://www.seeedstudio.com/Seeed-Studio-XIAO-ESP32C5-p-6609.html) ， [Seeed Studio XIAO ESP32-C3](https://www.seeedstudio.com/Seeed-XIAO-ESP32C3-p-5431.html) ， [Seeed Studio XIAO ESP32-C6](https://www.seeedstudio.com/Seeed-Studio-XIAO-ESP32C6-p-5884.html) ， [Seeed Studio XIAO ESP32-S3 Sense](https://www.seeedstudio.com/XIAO-ESP32S3-Sense-p-5639.html)
- **Expansion:** null
- **Grove Ecosystem:** null

[View project](https://www.youtube.com/watch?v=CfIjInYch7U)

---

## ESP32 Matter Tutorial #1 | Smart Bulb with XIAO ESP32 C6 (Arduino + Alexa) by techiesms

![Matter Tutorial](https://i.ytimg.com/vi/_TGsAgF8L88/maxresdefault.jpg)

The first installment of a practical **Matter protocol tutorial** using the **XIAO ESP32-C6**. This episode covers pairing a smart bulb with **Arduino** code and **Alexa** voice control, giving you a working Matter device you can extend to any smart home setup.

**Hardware Recommendation**
- **XIAO:** [Seeed Studio XIAO ESP32-C6](https://www.seeedstudio.com/Seeed-Studio-XIAO-ESP32C6-p-5884.html)
- **Expansion:** [Grove Shield for Seeeduino XIAO](https://www.seeedstudio.com/Grove-Shield-for-Seeeduino-XIAO-p-4621.html)
- **Grove Ecosystem:** [Grove - Temp & Humi Sensor (SHT40)](https://www.seeedstudio.com/Grove-Temp-Humi-Sensor-SHT40-p-5027.html)

[View project](https://www.youtube.com/watch?v=_TGsAgF8L88)

---

## why im building Ai cameras by Founders, Inc.

![AI Cameras](https://i.ytimg.com/vi/dS8DjZji6s8/maxresdefault.jpg)

The founder of **Hup** — a startup building **AI-powered cameras** on the **XIAO ESP32-S3 Sense** — explains the reasoning behind the platform. These cameras are designed to act as both a smart home hub and a security device, capable of conversational AI and local processing without relying on cloud services.

**Hardware Recommendation**
- **XIAO:** [Seeed Studio XIAO ESP32-S3 Sense](https://www.seeedstudio.com/XIAO-ESP32S3-Sense-p-5639.html)
- **Expansion:** null
- **Grove Ecosystem:** null

[View project](https://www.youtube.com/watch?v=dS8DjZji6s8)

---

## Xiao ESP32C3 & ESP32C6 Game Changer! Development board by Electronic Clinic

![ESP32C3 and ESP32C6 Review](https://i.ytimg.com/vi/NAq0QlphLSE/maxresdefault.jpg)

A detailed head-to-head comparison of the **XIAO ESP32C3** and **XIAO ESP32C6** boards. The video covers processing power, wireless capabilities, power consumption, and real-world performance benchmarks — helping you decide which compact XIAO is right for your next battery-powered project.

**Hardware Recommendation**
- **XIAO:** [Seeed Studio XIAO ESP32C3](https://www.seeedstudio.com/Seeed-XIAO-ESP32C3-p-5431.html) ， [Seeed Studio XIAO ESP32-C6](https://www.seeedstudio.com/Seeed-Studio-XIAO-ESP32C6-p-5884.html)
- **Expansion:** null
- **Grove Ecosystem:** null

[View project](https://www.youtube.com/watch?v=NAq0QlphLSE)

---

## XIAO ESP32-C5 Explained | Dual Band WiFi 6 ESP32 in a Tiny Board | Review + Tests by Electronic Clinic

![ESP32-C5 Review](https://i.ytimg.com/vi/SRNlok6IJ-U/maxresdefault.jpg)

A thorough review of the **XIAO ESP32-C5** — Seeed's first XIAO with **tri-band WiFi 6** (2.4GHz + 5GHz). The video runs through RF performance, power draw, and thermal behavior, putting this compact high-speed board through its paces.

**Hardware Recommendation**
- **XIAO:** [Seeed Studio XIAO ESP32-C5](https://www.seeedstudio.com/Seeed-Studio-XIAO-ESP32C5-p-6609.html)
- **Expansion:** null
- **Grove Ecosystem:** null

[View project](https://www.youtube.com/watch?v=SRNlok6IJ-U)

---

## I Built an AI Desk Buddy with ESP32 (Xiaozhi + Custom Face UI) by Tech Talkies

![AI Desk Buddy](https://i.ytimg.com/vi/aDaSp6zaqWM/maxresdefault.jpg)

An AI companion device powered by the **XIAO ESP32-S3**, using **Xiaozhi AI** and a custom animated face UI. The project combines voice interaction, ChatGPT integration, and a expressive display to create a genuinely engaging desktop assistant that reacts to conversation in real time.

**Hardware Recommendation**
- **XIAO:** [Seeed Studio XIAO ESP32-S3](https://www.seeedstudio.com/XIAO-ESP32S3-p-5627.html)
- **Expansion:** null
- **Grove Ecosystem:** null

[View project](https://www.youtube.com/watch?v=aDaSp6zaqWM)

---

## Control a Sphero RVR with Seeed Studio ESP32S3 over AWS IoT Core by Chiwai Chan

![Sphero RVR AWS IoT](https://i.ytimg.com/vi/WM8tDXyR6oo/sd2.jpg)

A step-by-step guide to connecting a **Sphero RVR** to **AWS IoT Core** using the **XIAO ESP32-S3**. The tutorial covers MQTT configuration, credential management, and writing the firmware that bridges the RVR's serial protocol to AWS cloud commands.

**Hardware Recommendation**
- **XIAO:** [Seeed Studio XIAO ESP32-S3](https://www.seeedstudio.com/XIAO-ESP32S3-p-5627.html)
- **Expansion:** null
- **Grove Ecosystem:** null

[View project](https://www.youtube.com/watch?v=WM8tDXyR6oo)

---

## World's Smallest Joystick Remote Control by Markus Opitz

A remarkably compact **joystick remote control** built on the **XIAO nRF52840 (XIAO BLE)** that puts you in charge of your project from anywhere. Featured in the 2025 STEM series, the build shows how to shrink control down to pocket size without sacrificing responsiveness.

**Hardware Recommendation**
- **XIAO:** [Seeed Studio XIAO BLE (nRF52840)](https://www.seeedstudio.com/Seeed-Studio-XIAO-BLE-nRF52840-p-5201.html)
- **Expansion:** null
- **Grove Ecosystem:** null

[View project](https://www.instructables.com/Worlds-Smallest-Joystick-Remote-Control/)

---

## Desktop Companion Robot by roboattic Lab

A expressive **desktop robot** with animated "roboEyes" on a 0.9" OLED, powered by the **XIAO ESP32-S3**. The robot mirrors your computer's activity state — showing whether you're typing, playing music, browsing, or gaming — and responds with subtle animations that bring the display to life.

**Hardware Recommendation**
- **XIAO:** [Seeed Studio XIAO ESP32-S3](https://www.seeedstudio.com/XIAO-ESP32S3-p-5627.html)
- **Expansion:** null
- **Grove Ecosystem:** [Grove - OLED Display 0.96" (SSD1306)](https://www.seeedstudio.com/Grove-OLED-Display-0.96-p-781.html)

[View project](https://www.instructables.com/Desktop-Companion-Robot)

---

## Building a Lightweight Curved E-Ink Smartwatch by Selbyc

A rugged, comfortable, and fully **hackable e-ink smartwatch** built around the **XIAO nRF52840 (XIAO BLE)** and a 2.9-inch flexible Waveshare display. The project documents the entire design process — from early breadboard prototypes through to the final 3D-printed enclosure — and the watch runs for weeks on a single charge.

**Hardware Recommendation**
- **XIAO:** [Seeed Studio XIAO BLE (nRF52840)](https://www.seeedstudio.com/Seeed-Studio-XIAO-BLE-nRF52840-p-5201.html)
- **Expansion:** null
- **Grove Ecosystem:** null

[View project](https://www.instructables.com/Building-a-Lightweight-Curved-EInk-Smartwatch/)

---

## The Next Holiday - E-Paper Countdown Panel by Profe Tolocka

An e-Paper panel that counts down the days until the next public holiday, built with the **XIAO ESP32-S3** and the **Seeed_GFX library**. The low-power display updates only when needed, running indefinitely from a small LiPo battery. A simple, satisfying project that solves an all-too-common office distraction.

**Hardware Recommendation**
- **XIAO:** [Seeed Studio XIAO ESP32-S3](https://www.seeedstudio.com/XIAO-ESP32S3-p-5627.html)
- **Expansion:** null
- **Grove Ecosystem:** null

[View project](https://www.hackster.io/etolocka/the-next-holiday-0b68b4)

---

## This $30 Project Puts You in the Driver's Seat of an RC Car by Nick Bild

A **4WD FPV racing car** built for under $30, powered by the **XIAO ESP32-S3 Sense** which handles both live video streaming and motor control. The car creates its own WiFi hotspot — connect a phone or laptop browser to drive and watch in real time from the onboard camera's perspective.

**Hardware Recommendation**
- **XIAO:** [Seeed Studio XIAO ESP32-S3 Sense](https://www.seeedstudio.com/XIAO-ESP32S3-Sense-p-5639.html)
- **Expansion:** null
- **Grove Ecosystem:** null

[View project](https://www.hackster.io/news/this-30-project-puts-you-in-the-driver-s-seat-of-an-rc-car-0e39a66f5f03)

---

## Half Pill – a Minimal Smart Desk Pill Reminder by Gokul

A Wi-Fi enabled **desk pill reminder** built with the **XIAO ESP32-C3** and the **Seeed Studio Round Display**. The device shows scheduled medication times on the round screen and alerts you when it's time — compact enough to sit unobtrusively on any desk while being harder to miss than a phone notification.

**Hardware Recommendation**
- **XIAO:** [Seeed Studio XIAO ESP32-C3](https://www.seeedstudio.com/Seeed-XIAO-ESP32C3-p-5431.html)
- **Expansion:** [Seeed Studio Round Display for XIAO](https://www.seeedstudio.com/Seeed-Studio-Round-Display-for-XIAO-p-5638.html)
- **Grove Ecosystem:** null

[View project](https://www.hackster.io/Gokux/half-pill-a-minimal-smart-desk-pill-reminder-34f8f5)

---

## Now Playing - XIAO ESP32-C6 Round Display Media Player by gxlabs

A smart display that shows what's currently playing on your desk — music, video, or any media — driven by the **XIAO ESP32-C6** and the **Round Display**. The round screen gives it a distinctive look compared to conventional rectangular displays, and the UI is designed to match the circular form factor.

**Hardware Recommendation**
- **XIAO:** [Seeed Studio XIAO ESP32-C6](https://www.seeedstudio.com/Seeed-Studio-XIAO-ESP32C6-p-5884.html)
- **Expansion:** [Seeed Studio Round Display for XIAO](https://www.seeedstudio.com/Seeed-Studio-Round-Display-for-XIAO-p-5638.html)
- **Grove Ecosystem:** null

[View project](https://www.gxlabs.co/now-playing/)

---

## ESP32 in 2026 - The Complete Guide by DroneBot Workshop

The definitive long-form reference covering the entire **ESP32 family in 2026** — from the original ESP32 through the latest **ESP32-C6 and ESP32-H2**, with a dedicated focus on the **XIAO ESP32-S3**. This article-format guide by DroneBot Workshop is the best starting point for anyone evaluating ESP32 for a new project, with clear recommendations for different use cases.

**Hardware Recommendation**
- **XIAO:** [Seeed Studio XIAO ESP32-S3](https://www.seeedstudio.com/XIAO-ESP32S3-p-5627.html)
- **Expansion:** null
- **Grove Ecosystem:** null

[View project](https://dronebotworkshop.com/esp32-2026/)

---

## Hup Smart Camera - AI-Powered XIAO Camera by withhup

An **AI-powered smart camera platform** built on the **XIAO ESP32-S3 Sense**, developed by **Hup**. The camera integrates voice interaction, local AI processing, and smart home control into a single device — designed to handle everyday tasks like checking who's at the door or adjusting your thermostat without sending data to the cloud.

**Hardware Recommendation**
- **XIAO:** [Seeed Studio XIAO ESP32-S3 Sense](https://www.seeedstudio.com/XIAO-ESP32S3-Sense-p-5639.html)
- **Expansion:** null
- **Grove Ecosystem:** null

[View project](https://www.withhup.com/#features)

---

## XIAO Board Selection Guide

Use this reference table to choose the right XIAO board for your next project.

| Parameter | [SAMD21](https://www.seeedstudio.com/Seeeduino-XIAO-Arduino-Microcontroller-SAMD21-Cortex-M0+-p-4426.html) | [RP2040](https://www.seeedstudio.com/XIAO-RP2040-v1-0-p-5026.html) | [RP2350](https://www.seeedstudio.com/Seeed-XIAO-RP2350-p-5944.html) | [nRF52840](https://www.seeedstudio.com/Seeed-Studio-XIAO-BLE-nRF52840-p-5201.html) | [nRF52840 Sense](https://www.seeedstudio.com/Seeed-Studio-XIAO-BLE-Sense-nRF52840-p-5253.html) | [ESP32C3](https://www.seeedstudio.com/Seeed-XIAO-ESP32C3-p-5431.html) | [ESP32C5](https://www.seeedstudio.com/Seeed-Studio-XIAO-ESP32C5-p-6609.html) | [ESP32C6](https://www.seeedstudio.com/Seeed-Studio-XIAO-ESP32C6-p-5884.html) | [ESP32S3](https://www.seeedstudio.com/XIAO-ESP32S3-p-5627.html) | [ESP32S3 Sense](https://www.seeedstudio.com/XIAO-ESP32S3-Sense-p-5639.html) | [RA4M1](https://www.seeedstudio.com/Seeed-XIAO-RA4M1-p-5943.html) | [MG24](https://www.seeedstudio.com/Seeed-Studio-XIAO-MG24-p-6247.html) | [MG24 Sense](https://www.seeedstudio.com/Seeed-Studio-XIAO-MG24-Sense-p-6248.html) | [nRF54L15](https://www.seeedstudio.com/Seeed-Studio-XIAO-nRF54L15-p-6493.html) | [nRF54L15 Sense](https://www.seeedstudio.com/Seeed-Studio-XIAO-nRF54L15-Sense-p-6494.html) |
|-----------|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **Chip** | SAMD21 | RP2040 | RP2350 | nRF52840 | nRF52840 | ESP32C3 | ESP32-C5 | ESP32C6 | ESP32S3 | ESP32S3 | RA4M1 | EFR32MG24 | EFR32MG24 | nRF54L15 | nRF54L15 |
| **Arch / Clock** | Cortex-M0+ @ 48MHz | Dual Cortex-M0+ @ 133MHz | Dual Cortex-M33 + RISC-V @ 150MHz | Cortex-M4 @ 64MHz | Cortex-M4 @ 64MHz | RISC-V @ 160MHz | RISC-V @ 240MHz | Dual RISC-V 160+20MHz | Dual Xtensa LX7 @ 240MHz | Dual Xtensa LX7 @ 240MHz | Cortex-M4 + FPU @ 48MHz | Cortex-M33 @ 78MHz | Cortex-M33 @ 78MHz | Dual-core M33+RISC-V @ 128MHz | Dual-core M33+RISC-V @ 128MHz |
| **SRAM** | 32 KB | 264 KB | 520 KB | 256 KB | 256 KB | 400 KB | 384 KB | 512 KB | 512 KB | 512 KB | 32 KB | 256 KB | 256 KB | 256 KB | 256 KB |
| **Internal Flash** | 256 KB | — | — | 1 MB | 1 MB | 4 MB | — | 4 MB | 384 KB ROM | 384 KB ROM | 256 KB | 1536 KB + 4 MB | 1536 KB + 4 MB | 1.5 MB | 1.5 MB |
| **Onboard Flash** | — | 2 MB | — | 2 MB | 2 MB | — | 8 MB | — | 8 MB | 8 MB | — | — | — | — | — |
| **Built-in Sensors** | — | — | — | — | IMU + Microphone | — | — | — | — | Camera + Microphone | — | — | IMU + Microphone | — | IMU + Microphone |
| **WiFi** | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ✅ WiFi 6 (5G) | ✅ WiFi 6 | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **BLE** | ❌ | ❌ | ❌ | ✅ 5.0 | ✅ 5.0 | ✅ 5.0 | ✅ 5.0 | ✅ 5.0 | ✅ 5.0 | ✅ 5.0 | ❌ | ✅ 5.3 | ✅ 5.3 | ✅ 6.0 | ✅ 6.0 |
| **Low Power** | — | — | 50 μA | 5 μA | 5 μA | 44 μA | — | 15 μA | 14 μA | 26.5 mA | 45 μA | 1.95 μA | 1.95 μA | — | — |
| **Arduino** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| **PlatformIO** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **MicroPython** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | ✅ |
| **CircuitPython** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **Zephyr** | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ | ✅ |
