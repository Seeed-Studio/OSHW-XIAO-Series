# Seeed Studio XIAO Series — Complete Selection Guide

---

## Seeed Studio XIAO Series — Complete Selection Guide

| Parameter | [XIAO SAMD21](https://www.seeedstudio.com/Seeeduino-XIAO-Arduino-Microcontroller-SAMD21-Cortex-M0+-p-4426.html) | [XIAO RP2040](https://www.seeedstudio.com/XIAO-RP2040-v1-0-p-5026.html) | [XIAO RP2350](https://www.seeedstudio.com/Seeed-XIAO-RP2350-p-5944.html) | [XIAO nRF52840](https://www.seeedstudio.com/Seeed-XIAO-BLE-nRF52840-p-5201.html) | [XIAO nRF52840 Sense](https://www.seeedstudio.com/Seeed-XIAO-BLE-Sense-nRF52840-p-5253.html) | [XIAO ESP32C3](https://www.seeedstudio.com/Seeed-XIAO-ESP32C3-p-5431.html) | [XIAO ESP32C5](https://www.seeedstudio.com/Seeed-Studio-XIAO-ESP32C5-p-6609.html) | [XIAO ESP32C6](https://www.seeedstudio.com/Seeed-Studio-XIAO-ESP32C6-p-5884.html) | [XIAO ESP32S3](https://www.seeedstudio.com/XIAO-ESP32S3-p-5627.html) | [XIAO ESP32S3 Sense](https://www.seeedstudio.com/XIAO-ESP32S3-Sense-p-5639.html) | [RA4M1](https://www.seeedstudio.com/Seeed-XIAO-RA4M1-p-5943.html) | [XIAO MG24](https://www.seeedstudio.com/Seeed-Studio-XIAO-MG24-p-6247.html) | [XIAO MG24 Sense](https://www.seeedstudio.com/Seeed-XIAO-MG24-Sense-p-6248.html) | [XIAO nRF54L15](https://www.seeedstudio.com/XIAO-nRF54L15-p-6493.html) | [XIAO nRF54L15 Sense](https://www.seeedstudio.com/XIAO-nRF54L15-Sense-p-6494.html) |
|-----------|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **Chip** | SAMD21 | RP2040 | RP2350 | nRF52840 | nRF52840 | ESP32C3 | ESP32-C5 | ESP32C6 | ESP32S3 | ESP32S3 | RA4M1 | EFR32MG24 | EFR32MG24 | nRF54L15 | nRF54L15 |
| **Arch / Clock** | Cortex-M0+ @ 48MHz | Dual Cortex-M0+ @ 133MHz | Dual Cortex-M33 + RISC-V @ 150MHz | Cortex-M4 @ 64MHz | Cortex-M4 @ 64MHz | RISC-V @ 160MHz | RISC-V @ 240MHz | Dual RISC-V 160+20MHz | Dual Xtensa LX7 @ 240MHz | Dual Xtensa LX7 @ 240MHz | Cortex-M4 + FPU @ 48MHz | Cortex-M33 @ 78MHz | Cortex-M33 @ 78MHz | Dual-core M33+RISC-V @ 128MHz | Dual-core M33+RISC-V @ 128MHz |
| **SRAM** | 32 KB | 264 KB | 520 KB | 256 KB | 256 KB | 400 KB | 384 KB | 512 KB | 512 KB | 512 KB | 32 KB | 256 KB | 256 KB | 256 KB | 256 KB |
| **Internal Flash** | 256 KB | — | — | 1 MB | 1 MB | 4 MB | — | 4 MB | 384 KB ROM | 384 KB ROM | 256 KB | 1536 KB + 4 MB | 1536 KB + 4 MB | 1.5 MB | 1.5 MB |
| **Onboard Flash** | — | 2 MB | — | 2 MB | 2 MB | — | 8 MB | — | 8 MB | 8 MB | — | — | — | — | — |
| **Built-in Sensors** | — | — | — | — | IMU + Microphone | — | — | — | — | Camera + Microphone | — | — | IMU + Microphone | — | IMU + Microphone |
| **PWM / ADC** | 11 / 11 | 11 / 4 | 19 / 3 | 11 / 6 | 11 / 6 | 11 / 4 | 11 / 5 | 11 / 7 | 11 / 9 | 13 / 11 | 19 / 14 | 22 / 18 | 22 / 18 | 16 / 4 | 14 / 4 |
| **WiFi** | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ✅ WiFi 6 (5G) | ✅ WiFi 6 | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **BLE** | ❌ | ❌ | ❌ | ✅ 5.0 | ✅ 5.0 | ✅ 5.0 | ✅ 5.0 | ✅ 5.0 | ✅ 5.0 | ✅ 5.0 | ❌ | ✅ 5.3 | ✅ 5.3 | ✅ 6.0 | ✅ 6.0 |
| **Low Power** | — | — | 50 μA | 5 μA | 5 μA | 44 μA | — | 15 μA | 14 μA | 26.5 mA | 45 μA | 1.95 μA | 1.95 μA | — | — |
| **Arduino** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| **PlatformIO** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **MicroPython** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | ✅ |
| **CircuitPython** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **Zephyr** | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ | ✅ |


---

## Seeed Studio XIAO Expansion Board Products

---

### 1. Seeeduino XIAO Expansion Board
A rich-peripherals base board with **OLED display, RTC, SD card slot, passive buzzer, RESET/User button**, and battery management. Supports XIAO SAMD21, RP2040, and nRF52840. Compact at half Raspberry Pi 4 size.

<https://www.seeedstudio.com/Seeeduino-XIAO-Expansion-board-p-4746.html>

---

### 2. Grove Shield for Seeeduino XIAO
Plug-and-play Grove extension board with **8 Grove connectors** (2 I2C, 1 UART), onboard **battery management chip**, and SPI-Flash expansion pads. Ideal for wearable projects.

<https://www.seeedstudio.com/Grove-Shield-for-Seeeduino-XIAO-p-4621.html>

---

### 3. Bus Servo Driver Board / XIAO Bus Servo Adapter
General-purpose serial bus servo interface. The **XIAO Bus Servo Adapter** includes an **ESP32-C3** onboard with a 3D-printed case for ready-to-use robotics control.

- Board only: <https://www.seeedstudio.com/Bus-Servo-Driver-Board-for-XIAO-p-6413.html>
- With XIAO ESP32-C3: <https://www.seeedstudio.com/XIAO-Bus-Servo-Adapter-for-XIAO-p-6397.html>

---

### 4. COB LED Driver Board for XIAO
7-channel COB LED driver with **3× 300mA high-power + 4× 80mA dimmable channels**, tailored for **1mm 3V COB strips**. Integrated PMIC battery management for portable high-brightness wireless lighting.

<https://www.seeedstudio.com/COB-LED-Driver-Board-for-Seeed-Studio-XIAO-p-6602.html>

---

### 5. LED Driver Board for XIAO
Smart LED driver supporting **5V/3A and 12V/2A** strips. Compatible with addressable RGB LEDs (**WS2812, WS2813, WS2815, SK6812**). Pairs with XIAO ESP32 series for **WLED** and **Home Assistant** control.

<https://www.seeedstudio.com/LED-Driver-Board-for-XIAO-p-6451.html>

---

### 6. 6x10 RGB MATRIX for XIAO
**60 WS2812 LEDs** arranged in a 6×10 grid. Compact 1mm×1mm per LED. Perfect for dynamic displays, notifications, wearable tech, and art installations.

<https://www.seeedstudio.com/6x10-RGB-MATRIX-for-XIAO-p-5771.html>

---

### 7. Round Display for XIAO
**39mm circular touchscreen** (240×240 resolution) with onboard **RTC, charge chip, and TF card slot**. Compatible with all XIAO boards. Great for smart home UI and wearable interfaces.

<https://www.seeedstudio.com/Seeed-Studio-Round-Display-for-XIAO-p-5638.html>

---

### 8. ePaper Driver Board V2
Breakout board with **24-pin FPC connector**, built-in **charging IC**, and JST 2-pin BAT connector. Designed for WiFi-enabled digital photo frames and low-power displays.

<https://www.seeedstudio.com/ePaper-breakout-Board-for-XIAO-V2-p-6374.html>

---

### 9. ePaper Breakout Board
Universal eInk driver with **24-pin FPC + 8-pin 2.54 header**. Can use XIAO or any microcontroller. Display not included.

<https://www.seeedstudio.com/ePaper-Breakout-Board-p-5804.html>

---

### 10. XIAO CAN Bus Expansion Board
Adds **CAN bus** communication via **MCP2515 + SN65HVD230**. For automotive, industrial, and robotics applications requiring robust multi-node communication.

<https://www.seeedstudio.com/Seeed-Studio-CAN-Bus-Breakout-Board-for-XIAO-and-QT-Py-p-5702.html>

---

### 11. XIAO RS485 Expansion Board
Adds **RS485 serial communication** for industrial control, long-distance wired communication, and automation systems.

<https://www.seeedstudio.com/RS485-Breakout-Board-for-XIAO-p-6306.html>

---

### 12. GPIO Expander for XIAO
Powered by **MCP23017**, adds **16 extra IO pins** via **I2C** (default address 0x21, configurable to 0x20). For projects requiring more I/O than XIAO natively offers.

<https://www.seeedstudio.com/GPIO-Expander-for-XIAO-p-5795.html>

---

### 13. L76K GNSS Module for SeeedStudio XIAO
Multi-GNSS module supporting **GPS, BeiDou, GLONASS, QZSS**. Features **AGNSS**, **LNA + SAW filter**, 32/72 channels, and ceramic antenna for fast, accurate positioning.

<https://www.seeedstudio.com/L76K-GNSS-Module-for-Seeed-Studio-XIAO-p-5864.html>


---

## Grove Ecosystem Products（ Grove 生态产品）

---

### 1. Grove - VOC and eCO2 Gas Sensor (SGP30)
实时监测 VOC（挥发性有机化合物）和 eCO2（等效二氧化碳）浓度，基于 Sensirion SGP30 芯片，I2C 接口，适用于室内空气质量监测。
<https://www.seeedstudio.com/Grove-VOC-and-eCO2-Gas-Sensor-SGP30-p-3071.html>

---

### 2. Grove - Temperature, Humidity, Pressure and Gas Sensor (BME680)
全能型环境传感器，集成温湿度、气压和气体监测功能，基于 Bosch BME680，I2C 接口，适合 IoT 和环境监测项目。
<https://www.seeedstudio.com/Grove-Temperature-Humidity-Pressure-Gas-Sensor-BME680-p-3109.html>

---

### 3. Grove - Time of Flight Distance Sensor (VL53L0X)
基于 ST Microelectronics VL53L0X 激光测距传感器，测量距离最远 2m，精度 ±3%，I2C 接口，适用于避障和距离检测。
<https://www.seeedstudio.com/Grove-Time_of_Flight_Distance_Sensor-VL53L0X-p-3070.html>

---

### 4. Grove - Digital Distance Interrupter 0.5 to 5cm (GP2Y0D805Z0F)
数字式红外距离传感器，检测范围 0.5-5cm，Sharp GP2Y0D805Z0F 芯片，数字输出，响应速度快。
<https://www.seeedstudio.com/Grove-Digital-Distance-Interrupter-p-4577.html>

---

### 5. Grove - 12 Key Capacitive I2C Touch Sensor V2 (MPR121)
12 通道电容式触摸传感器，基于 MPR121 芯片，I2C 接口，适用于触摸按键、开关和液位检测。
<https://www.seeedstudio.com/Grove-12-Key-Capacitive-I2C-Touch-Sensor-V2-p-3137.html>

---

### 6. Grove - 12 Key Capacitive I2C Touch Sensor V3 (MPR121)
MPR121 升级版，12 通道电容触摸，I2C 接口，功耗低，支持中断输出。
<https://www.seeedstudio.com/Grove-12-Key-Capacitive-I2C-Touch-Sensor-V3-p-4330.html>

---

### 7. Grove - Round Force Sensor (FSR402)
圆形力敏传感器，Interlink Electronics FSR402，压力检测范围 100g-10kg，适用于按压检测和力度测量。
<https://www.seeedstudio.com/Grove-Round-Force-Sensor-FSR402-p-3138.html>

---

### 8. Grove - 1-Wire Thermocouple Amplifier (MAX31850K)
支持 K 型热电偶的放大器模块，1-Wire 接口，精度 ±2°C，适用高温测量（-200°C 至 +1350°C）。
<https://www.seeedstudio.com/Grove-1-Wire-Thermocouple-Amplifier-MAX31850K-p-3140.html>

---

### 9. Grove - I2C High Accuracy Temperature Sensor (MCP9808)
高精度 I2C 温度传感器，精度 ±0.25°C（典型），测量范围 -40°C 至 +125°C，功耗低。
<https://www.seeedstudio.com/Grove-I2C-High-Accuracy-Temperature-Sensor-MCP9808-p-3141.html>

---

### 10. Grove - Infrared Temperature Sensor Array (AMG8833)
8x8 红外热像阵列传感器，检测范围 0°C 至 +80°C，I2C 接口，可用于人像检测和热成像项目。
<https://www.seeedstudio.com/Grove-Infrared-Temperature-Sensor-Array-AMG8833-p-3142.html>

---

### 11. Grove - Light & Gesture & Color & Proximity Sensor (TMG39931)
集成光照、手势、颜色和接近检测的四合一传感器，I2C 接口，AMS TMG39931 芯片，适用于人机交互。
<https://www.seeedstudio.com/Grove-Light-Gesture-Color-Proximity-Sensor-TMG39931-p-3159.html>

---

### 12. Grove - 3-Axis Digital Accelerometer ±16g Ultra-low Power (BMA400)
超低功耗 3 轴数字加速度计，量程 ±16g，I2C/SPI 接口，功耗仅 1.5µA，适合可穿戴设备。
<https://www.seeedstudio.com/Grove-3-Axis-Digital-Accelerometer-BMA400-p-3155.html>

---

### 13. Grove - Step Counter (BMA456)
内置步数计数算法的 3 轴加速度计，无需外部算法即可输出步数，I2C 接口，适合计步器应用。
<https://www.seeedstudio.com/Grove-Step-Counter-BMA456-p-3156.html>

---

### 14. Grove - 6-Axis Accelerometer & Gyroscope (BMI088)
6 轴惯性测量单元（IMU），集成 3 轴加速度计和 3 轴陀螺仪，I2C/SPI 接口，高精度，适用于无人机和机器人。
<https://www.seeedstudio.com/Grove-6-Axis-Accelerometer-Gyroscope-BMI088-p-3157.html>

---

### 15. Grove - IMU 9DOF (ICM20600 & AK09918)
9 自由度 IMU 模块，ICM20600（六轴）+ AK09918（三轴磁力计），I2C/SPI 接口，适用于姿态检测和导航。
<https://www.seeedstudio.com/Grove-IMU-9DOF-ICM20600-AK09918-p-3158.html>

---

### 16. Grove - Vibration Sensor (SW-420)
震动传感器模块，基于 SW-420 探头，数字输出（高低电平），灵敏度高，适用于震动检测和报警项目。
<https://www.seeedstudio.com/Grove-Vibration-Sensor-SW-420-p-3151.html>

---

### 17. Grove - Optical Rotary Encoder (TCUT1600X01)
光学旋转编码器模块，TCUT1600X01，无接触式，分辨率取决于配套码盘，适用于电机转速和位置检测。
<https://www.seeedstudio.com/Grove-Optical-Rotary-Encoder-TCUT1600X01-p-3152.html>

---

### 18. Grove - I2C High Accuracy Temp & Humi Sensor (SHT35)
Sensirion SHT35 高精度温湿度传感器，I2C 接口，湿度精度 ±1.5%RH，温度精度 ±0.2°C。
<https://www.seeedstudio.com/Grove-I2C-High-Accuracy-Temp-Humi-Sensor-SHT35-p-3183.html>

---

### 19. Grove - Coulomb Counter 3.3V to 5V (LTC2941)
库仑计（电量计），基于 LTC2941 芯片，测量范围 3.3V-5V，I2C 接口，可精确测量电池充放电容量。
<https://www.seeedstudio.com/Grove-Coulomb-Counter-LTC2941-p-3185.html>

---

### 20. Grove - 2-Channel Inductive Sensor (LDC1612)
2 通道电感式传感器，基于 TI LDC1612，I2C 接口，适用于金属目标检测和位置测量，无需接触金属。
<https://www.seeedstudio.com/Grove-2-Channel-Inductive-Sensor-LDC1612-p-3186.html>

---

### 21. Grove - Optocoupler Relay (M281)
光耦隔离继电器模块，M281 芯片，支持 5V 控制 24V AC/DC，数字接口，适合隔离保护应用。
<https://www.seeedstudio.com/Grove-Optocoupler-Relay-M281-p-3188.html>

---

### 22. Grove - Laser PM2.5 Sensor (HM3301)
激光 PM2.5 传感器，基于 HM3301，UART 接口，可同时检测 PM1.0/PM2.5/PM10，适用于空气净化器和空气质量监测。
<https://www.seeedstudio.com/Grove-Laser-PM2.5-Sensor-HM3301-p-3199.html>

---

### 23. Grove - Capacitive Moisture Sensor (Corrosion Resistant)
电容式土壤湿度传感器，防腐蚀版本，模拟输出，适用于农业灌溉和土壤湿度监测。
<https://www.seeedstudio.com/Grove-Capacitive-Moisture-Sensor-p-3205.html>

---

### 24. Grove - ±5A DC/AC Current Sensor (ACS70331)
电流传感器，基于 ACS70331，量程 ±5A，模拟输出，响应时间 1µs，适用于电机控制和电源监测。
<https://www.seeedstudio.com/Grove-5A-DC-AC-Current-Sensor-ACS70331-p-3206.html>

---

### 25. Grove - 10A DC Current Sensor (ACS725)
10A 直流电流传感器，ACS725LRXTR-10AU，模拟输出，功耗低，适合大电流检测应用。
<https://www.seeedstudio.com/Grove-10A-DC-Current-Sensor-ACS725-p-3207.html>

---

### 26. Grove - Adjustable PIR Motion Sensor
可调 PIR 人体红外运动传感器，数字输出，检测距离和延迟时间可调，适用于照明和安防触发。
<https://www.seeedstudio.com/Grove-Adjustable-PIR-Motion-Sensor-p-3209.html>

---

### 27. Grove - 3-Axis Digital Accelerometer ±200g (ADXL372)
超高量程 3 轴加速度计，±200g，I2C/SPI 接口，超低功耗，适合冲击和碰撞检测。
<https://www.seeedstudio.com/Grove-3-Axis-Digital-Accelerometer-ADXL372-p-3224.html>

---

### 28. Grove - CO2 & Temperature & Humidity Sensor (SCD30)
Sensirion SCD30 CO2 传感器，集成温湿度，I2C/UART 接口，量程 0-40,000ppm，适合温室和空气质量监测。
<https://www.seeedstudio.com/Grove-CO2-Temperature-Humidity-Sensor-SCD30-p-3225.html>

---

### 29. Grove - Water Level Sensor (10CM)
10cm 水位传感器，模拟输出，适用浅水位检测，如容器液位或雨水监测。
<https://www.seeedstudio.com/Grove-Water-Level-Sensor-10CM-p-3226.html>

---

### 30. Grove - 12-Channel Capacitive Touch Keypad (ATtiny1616)
12 通道电容触摸键盘，基于 ATtiny1616，I2C 接口，支持多按键同时检测，适合自定义键盘和控制面板。
<https://www.seeedstudio.com/Grove-12-Channel-Capacitive-Touch-Keypad-ATtiny1616-p-3227.html>

---

### 31. Grove - 3-Axis Analog Accelerometer ±20g (ADXL356B)
模拟输出 3 轴加速度计，量程 ±20g，ADXL356B，功耗低，模拟电压输出，适合高精度振动分析。
<https://www.seeedstudio.com/Grove-3-Axis-Analog-Accelerometer-ADXL356B-p-3228.html>

---

### 32. Grove - 3-Axis Analog Accelerometer ±40g (ADXL356C)
模拟输出 3 轴加速度计，量程 ±40g，ADXL356C，适合工业级振动监测。
<https://www.seeedstudio.com/Grove-3-Axis-Analog-Accelerometer-ADXL356C-p-3229.html>

---

### 33. Grove - 3-Axis Digital Accelerometer ±40g (ADXL357)
数字输出 3 轴加速度计，量程 ±40g，I2C/SPI 接口，功耗低，适合高冲击环境。
<https://www.seeedstudio.com/Grove-3-Axis-Digital-Accelerometer-ADXL357-p-3230.html>

---

### 34. Grove - 2.5A DC Current Sensor (ACS70331)
2.5A 直流电流传感器，ACS70331，模拟输出，低噪声，适合电池管理系统。
<https://www.seeedstudio.com/Grove-2.5A-DC-Current-Sensor-ACS70331-p-3245.html>

---

### 35. Grove - 12-bit Magnetic Rotary Position Sensor (AS5600)
12 位磁编码器，AS5600，I2C 接口，无需接触即可测量旋转位置，适用于电机闭环控制。
<https://www.seeedstudio.com/Grove-12-bit-Magnetic-Rotary-Position-Sensor-AS5600-p-3260.html>

---

### 36. Grove - ADC for Load Cell (HX711)
24 位高精度 ADC，专为称重传感器设计，I2C/SPI 接口，适用于电子秤和力度测量。
<https://www.seeedstudio.com/Grove-ADC-for-Load-Cell-HX711-p-3261.html>

---

### 37. Grove - Capacitive Fingerprint Scanner
电容式指纹扫描模块，集成 DSP 处理器，支持录入/比对，UART 接口，适用于门禁和考勤系统。
<https://www.seeedstudio.com/Grove-Capacitive-Fingerprint-Scanner-p-3262.html>

---

### 38. Grove - Turbidity Sensor
浊度传感器，模拟输出，检测液体浑浊度，适用于水质监测和过滤系统。
<https://www.seeedstudio.com/Grove-Turbidity-Sensor-p-3282.html>

---

### 39. Grove - TDS Sensor
总溶解固体（TDS）传感器，模拟输出，测量水中溶解性固体含量，适用于水质检测。
<https://www.seeedstudio.com/Grove-TDS-Sensor-p-3283.html>

---

### 40. Grove - Digital PIR Motion Sensor
数字 PIR 人体运动传感器，检测距离 3-5m，数字输出，功耗低，适合安防和智能照明。
<https://www.seeedstudio.com/Grove-Digital-PIR-Motion-Sensor-p-3334.html>

---

### 41. Grove - High Precision Barometer Sensor (DPS310)
高精度气压传感器，DPS310，I2C/SPI 接口，气压精度 ±0.5hPa，适合高度计和天气预报。
<https://www.seeedstudio.com/Grove-High-Precision-Barometer-Sensor-DPS310-p-3339.html>

---

### 42. Grove - Multichannel Gas Sensor v2
多通道气体传感器，支持多种气体检测（需配合传感器阵列），I2C 接口，适用于环境监测。
<https://www.seeedstudio.com/Grove-Multichannel-Gas-Sensor-v2-p-3353.html>

---

### 43. Grove - Analog Microphone
模拟输出麦克风模块，灵敏度 -38dB，模拟电压输出，适用于声音检测和语音识别预处理。
<https://www.seeedstudio.com/Grove-Analog-Microphone-p-3356.html>

---

### 44. Grove - CO2 & Temperature & Humidity Sensor (SCD41)
Sensirion SCD41 高精度 CO2 传感器，I2C 接口，量程 0-40,000ppm，低功耗，适合室内空气质量监测。
<https://www.seeedstudio.com/Grove-CO2-Temperature-Humidity-Sensor-SCD41-p-5025.html>

---

### 45. Grove - Formaldehyde Sensor (SFA30)
甲醛检测传感器，SFA30，I2C 接口，测量范围 0-1000ppb，高灵敏度，适合室内空气检测。
<https://www.seeedstudio.com/Grove-Formaldehyde-Sensor-SFA30-p-5026.html>

---

### 46. Grove - Air Quality Sensor (SGP41)
VOC 和 NOx 传感器，SGP41，I2C 接口，数字输出，适合室内空气质量和 HVAC 控制。
<https://www.seeedstudio.com/Grove-Air-Quality-Sensor-SGP41-p-5695.html>

---

### 47. Grove - Air Quality Sensor (SGP40)
VOC 气体传感器，SGP40，I2C 接口，基于 Sensirion 技术，提供原始 VOC 信号输出。
<https://www.seeedstudio.com/Grove-Air-Quality-Sensor-SGP40-p-5700.html>

---

### 48. Grove - Lightning Sensor (AS3935)
闪电检测传感器，AS3935，I2C 接口，可检测 40km 范围内的闪电活动，适用于天气监测。
<https://www.seeedstudio.com/Grove-Lightning-Sensor-AS3935-p-4343.html>

---

### 49. Grove - All-in-one Environmental Sensor (SEN54)
全能环境传感器，集成 PM2.5、温湿度、VOC 和 NO2，I2C 接口，一站式解决空气质量监测需求。
<https://www.seeedstudio.com/Grove-All-in-one-Environmental-Sensor-SEN54-p-5023.html>

---

### 50. Grove - All-in-one Environmental Sensor (SEN55)
SEN54 升级版，额外集成了 CO2 检测，I2C 接口，更全面的空气质量监测方案。
<https://www.seeedstudio.com/Grove-All-in-one-Environmental-Sensor-SEN55-p-5024.html>

---

### 51. Grove - Temp & Humi Sensor (SHT40)
Sensirion SHT40 高精度温湿度传感器，I2C 接口，低功耗，精度高，适用各种环境监测。
<https://www.seeedstudio.com/Grove-Temp-Humi-Sensor-SHT40-p-5027.html>

---

### 52. Grove - Temp & Humi Sensor (SHT41)
Sensirion SHT41 高精度温湿度传感器，I2C 接口，比 SHT40 有更好的精度规格。
<https://www.seeedstudio.com/Grove-Temp-Humi-Sensor-SHT41-p-5028.html>

---

### 53. Grove - D7S Vibration Sensor
基于 Omron D7S 的地震震动传感器，I2C 接口，可检测和分类地震强度，适合地震监测预警系统。
<https://www.seeedstudio.com/Grove-D7S-Vibration-Sensor-p-5701.html>

---

### 54. Grove - IR Line Follower Sensor V3.0
红外循迹传感器，3 组发射/接收，模拟输出，适合循线机器人和工业检测。
<https://www.seeedstudio.com/Grove-IR-Line-Follower-Sensor-V3.0-p-4332.html>

---

### 55. Grove - Color Sensor V3.0
颜色识别传感器，I2C 接口，可识别多种颜色，TCS34725 芯片，适用于颜色分拣和匹配。
<https://www.seeedstudio.com/Grove-Color-Sensor-V3.0-p-4331.html>

---

### 56. Grove - AHT20 I2C Industrial Grade Temperature and Humidity Sensor
工业级 AHT20 温湿度传感器，I2C 接口，精度高，稳定性好，适用于工业环境。
<https://www.seeedstudio.com/Grove-AHT20-I2C-Industrial-Grade-Temperature-and-Humidity-Sensor-p-4509.html>

---

### 57. Grove - Oxygen Sensor (MIX8410)
氧气传感器，MIX8410，模拟输出，量程 0-100% O2，适用于医疗和环境氧气监测。
<https://www.seeedstudio.com/Grove-Oxygen-Sensor-MIX8410-p-4554.html>

---

### 58. Grove - AC Voltage Sensor
交流电压传感器，模拟输出，量程 0-250VAC，适合市电监测和电网传感器。
<https://www.seeedstudio.com/Grove-AC-Voltage-Sensor-p-4028.html>

---

### 59. Grove - Wizfi360
WiFi 模组，UART 接口，基于 WizFi360，支援 TCP/UDP/HTTP，适合 IoT 远程控制和数据传输。
<https://www.seeedstudio.com/Grove-Wizfi360-p-4308.html>

---

### 60. Grove - Smart IR Gesture Sensor
智能红外手势传感器，支持多种手势检测，UART 接口，适用人机交互和智能控制。
<https://www.seeedstudio.com/Grove-Smart-IR-Gesture-Sensor-p-4464.html>

---

### 61. Grove AI HAT for Edge Computing
边缘计算 AI 模块，集成 NPU，支持深度学习推理，Grove 接口，适合边缘 AI 应用。
<https://www.seeedstudio.com/Grove-AI-HAT-for-Edge-Computing-p-5563.html>

---

### 62. Grove for Scratch
Scratch 图形化编程 Grove 扩展，支持 Scratch 环境，适合编程教育和创客入门。
<https://www.seeedstudio.com/Grove-for-Scratch-p-4390.html>

---

### 63. Grove - Vision AI Module V2
内置 AI 加速器的视觉模块，Himax HX6537-A 处理器，OV2640 摄像头，支持人脸检测和自定义模型，I2C 接口。
<https://www.seeedstudio.com/Grove-Vision-AI-Module-V2-p-5459.html>

---

### 64. Grove - NFC (ST25DV64KC)
NFC/RFID 标签模块，ST25DV64K 芯片，支持 ISO/IEC 15693，I2C 接口，64Kbit EEPROM，适合近场通信和资产追踪。
<https://www.seeedstudio.com/Grove-NFC-ST25DV64KC-p-5688.html>

---

### 65. Grove - Thermal Imaging Camera (MLX90614 DCC)
红外热成像摄像头，MLX90614，35° FOV，I2C 接口，可测量物体表面温度，适合非接触测温。
<https://www.seeedstudio.com/Grove-Thermal-Imaging-Camera-MLX90614-DCC-p-4346.html>

---

### 66. Grove - Thermal Imaging Camera (MLX90641 BCB)
16x12 红外热阵列，MLX90641，55° FOV，I2C 接口，比 MLX90614 有更高分辨率的热成像。
<https://www.seeedstudio.com/Grove-Thermal-Imaging-Camera-MLX90641-BCB-p-4348.html>

---

### 67. Grove - Thermal Imaging Camera (MLX90621 BAB)
16x4 红外热阵列，MLX90621，60° FOV，I2C 接口，窄视场热探测，适合远距离目标检测。
<https://www.seeedstudio.com/Grove-Thermal-Imaging-Camera-MLX90621-BAB-p-4349.html>

---

### 68. Grove - Temperature & Humidity Sensor V2.0 (DHT20)
DHT20 温湿度传感器升级版，I2C 接口，精度高，稳定性好，替代传统 DHT11/DHT22。
<https://www.seeedstudio.com/Grove-Temperature-Humidity-Sensor-DH20-p-4562.html>

---

### 69. Grove - GPS (Air530)
高性能 GPS 模块，Air530 芯片，支持 GPS/Beidou/Glonass/Galileo/QZSS，UART 接口，适合导航和定位项目。
<https://www.seeedstudio.com/Grove-GPS-Air530-p-4584.html>

---

### 70. Grove - LoRa-E5 (STM32WLE5JC)
远距离低功耗 LoRaWAN 模块，STM32WLE5JC 芯片，支持 868/915MHz，UART AT 命令接口，传输距离可达 10km。
<https://www.seeedstudio.com/Grove-LoRa-E5-STM32WLE5JC-p-4867.html>

---

### 71. Grove - 2-Channel SPDT Relay
双通道 SPDT 继电器，5V 控制，可切换 max.250VAC/110VDC，10A 负载，适合家用电器控制。
<https://www.seeedstudio.com/Grove-2-Channel-SPDT-Relay-p-3118.html>

---

### 72. Grove - 4-Channel SPDT Relay
四通道 SPDT 继电器，I2C 接口（STM32F030 控制），可单独控制 4 路，10A 负载能力。
<https://www.seeedstudio.com/Grove-4-Channel-SPDT-Relay-p-3119.html>

---

### 73. Grove - 4-Channel Solid State Relay
四通道固态继电器，I2C 接口，基于 G3MC202P，支持 max.240VAC/2A，无噪音无火花。
<https://www.seeedstudio.com/Grove-4-Channel-Solid-State-Relay-p-3130.html>

---

### 74. Grove - 8-Channel Solid State Relay
八通道固态继电器，I2C 接口，支持 8 路 AC 负载控制，无机械磨损，切换速度更快。
<https://www.seeedstudio.com/Grove-8-Channel-Solid-State-Relay-p-3131.html>

---

### 75. Grove - Solid State Relay V2
单通道固态继电器 V2 版本，基于 G3MC202P，max.240VAC/2A，紧凑设计。
<https://www.seeedstudio.com/Grove-Solid-State-Relay-V2-p-3128.html>

---

### 76. Grove - RS232
RS232 串口通信模块，Grove 接口转 RS232，电平转换，适合连接工业设备和调制解调器。
<https://www.seeedstudio.com/Grove-RS232-p-3308.html>

---

### 77. Grove - RS485
RS485 串口通信模块，Grove 接口转 RS485，支持半双工通信，远距离传输（1200m），适合工业总线。
<https://www.seeedstudio.com/Grove-RS485-p-3309.html>

---

### 78. Grove - Breadboard
免焊接面包板，Grove 兼容孔位设计，方便原型搭建和临时电路测试。
<https://www.seeedstudio.com/Grove-Breadboard-p-3318.html>

---

### 79. Grove Shield for Wio Lite
Wio Lite 系列专用 Grove 扩展板，提供多个 Grove 接口，方便连接各种传感器和执行器。
<https://www.seeedstudio.com/Grove-Shield-for-Wio-Lite-p-4187.html>

---

### 80. Grove - I2C Hub (6 Port)
6 端口 I2C Hub，1 分 6，一进六出，方便连接多个 I2C 设备，解决接口不足问题。
<https://www.seeedstudio.com/Grove-I2C-Hub-6-Port-p-3125.html>

---

### 81. Grove - Qwiic Hub
Qwiic 接口 Hub，兼容 SparkFun Qwiic 系统，方便连接 Qwiic 生态设备。
<https://www.seeedstudio.com/Grove-Qwiic-Hub-p-4088.html>

---

### 82. Grove - 8 Channel I2C Hub (TCA9548A)
8 通道 I2C Hub，基于 TCA9548A，I2C 通道选择器，可通过 I2C 动态切换通道，扩展设备连接。
<https://www.seeedstudio.com/Grove-8-Channel-I2C-Hub-TCA9548A-p-4347.html>

---

### 83. Grove Base for XIAO
Seeed Studio XIAO 系列专用扩展板，集成多个 Grove 接口、电池管理和 SD 卡槽，适合便携和可穿戴项目。
<https://www.seeedstudio.com/Grove-Base-for-XIAO-p-4623.html>

---

### 84. Grove Base Hat for Raspberry Pi
Raspberry Pi Grove 扩展板，40Pin GPIO 扩展，多个 Grove 接口，兼容 Raspberry Pi 全系列。
<https://www.seeedstudio.com/Grove-Base-Hat-for-Raspberry-Pi-p-3186.html>

---

### 85. Grove Base Hat for Raspberry Pi Zero
Raspberry Pi Zero/Zero W/Zero 2W 专用 Grove 扩展板，compact 设计。
<https://www.seeedstudio.com/Grove-Base-Hat-for-Raspberry-Pi-Zero-p-3349.html>

---

### 86. Grove Shield for Particle Mesh
Particle Argon/Boron/Xenon 系列 Grove 扩展板，方便 Particle Mesh 设备连接 Grove 模块。
<https://www.seeedstudio.com/Grove-Shield-for-Particle-Mesh-p-3457.html>

---

### 87. MT3620 Grove Breakout
MT3620 Grove 分线板，Azure Sphere 专用，Grove 接口引出，方便 IoT 项目开发。
<https://www.seeedstudio.com/MT3620-Grove-Breakout-p-4042.html>

---

### 88. Grove Shield for Arduino Nano
Arduino Nano Grove 扩展板，携带多个 Grove 接口，与 Nano 引脚对应，nano 项目快速扩展。
<https://www.seeedstudio.com/Grove-Shield-for-Arduino-Nano-p-3417.html>

---

### 89. Grove Shield for Pi Pico v1.0
Raspberry Pi Pico Grove 扩展板，适配 Pico 和 Pico 2，多个 Grove 接口。
<https://www.seeedstudio.com/Grove-Shield-for-Pi-Pico-p-4805.html>

---

### 90. Grove - Red LED Matrix w/ Driver
红色 LED 点阵模块，带驱动芯片，8x8 显示，可级联，适合数字显示和滚动字幕。
<https://www.seeedstudio.com/Grove-Red-LED-Matrix-w-Driver-p-4290.html>

---

### 91. Grove - WS2813 RGB LED Strip Waterproof - 30 LED/m - 1m
防水 WS2813 RGB LED 灯带，30 颗/米，共 30 颗，1 米长，数字控制，5V供电。
<https://www.seeedstudio.com/Grove-WS2813-RGB-LED-Strip-Waterproof-30-LED-m-1m-p-4298.html>

---

### 92. Grove - WS2813 RGB LED Strip Waterproof - 60 LED/m - 1m
防水 WS2813 RGB LED 灯带，60 颗/米，共 60 颗，1 米长，更高密度，亮度更高。
<https://www.seeedstudio.com/Grove-WS2813-RGB-LED-Strip-Waterproof-60-LED-m-1m-p-4299.html>

---

### 93. Grove - 16 x 2 LCD (White on Blue)
16x2 字符 LCD，白字蓝底，I2C 接口，高对比度，简单易用的文字显示模块。
<https://www.seeedstudio.com/Grove-16-x-2-LCD-White-on-Blue-p-3196.html>

---

### 94. Grove - 16 x 2 LCD (Black on Red)
16x2 字符 LCD，黑字红底，I2C 接口，经典款式。
<https://www.seeedstudio.com/Grove-16-x-2-LCD-Black-on-Red-p-3197.html>

---

### 95. Grove - 16 x 2 LCD (Black on Yellow)
16x2 字符 LCD，黑字黄底，I2C 接口，宽视角。
<https://www.seeedstudio.com/Grove-16-x-2-LCD-Black-on-Yellow-p-3198.html>

---

### 96. Grove - RGB LED Ring (20 - WS2813 Mini)
20 颗 WS2813 Mini RGB LED 环形灯，紧凑直径，数字控制，炫彩效果，适合状态指示和装饰。
<https://www.seeedstudio.com/Grove-RGB-LED-Ring-20-WS2813-Mini-p-4296.html>

---

### 97. Grove - Triple Color E-Ink Display 1.54''
1.54 寸三色电子墨水屏，黑白红显示，SPI 接口，低功耗，阳光下可视，适合电子货架标签。
<https://www.seeedstudio.com/Grove-Triple-Color-E-Ink-Display-1.54-p-4338.html>

---

### 98. Grove - Triple Color E-Ink Display 2.13''
2.13 寸三色电子墨水屏，黑白红显示，SPI 接口，大尺寸低功耗显示。
<https://www.seeedstudio.com/Grove-Triple-Color-E-Ink-Display-2.13-p-4339.html>

---

### 99. Grove - RGB LED Stick (10 - WS2813 Mini)
10 颗 WS2813 Mini RGB LED 条形灯，数字控制，可编程显示各种颜色和效果。
<https://www.seeedstudio.com/Grove-RGB-LED-Stick-10-WS2813-Mini-p-4295.html>

---

### 100. Grove - 0.54" Red Dual Alphanumeric Display
0.54 寸红色双字符显示管，2 位数字/字母，I2C 接口，适合小型数字显示。
<https://www.seeedstudio.com/Grove-0.54inch-Red-Dual-Alphanumeric-Display-p-4340.html>

---

### 101. Grove - 0.54'' Red Quad Alphanumeric Display
0.54 寸红色四字符显示管，4 位数字/字母，I2C 接口，显示更多信息。
<https://www.seeedstudio.com/Grove-0.54inch-Red-Quad-Alphanumeric-Display-p-4341.html>

---

### 102. Grove - RGB LED Ring (24-WS2813 Mini)
24 颗 WS2813 Mini RGB LED 环形灯，数字控制，均匀发光效果，适合可视化反馈。
<https://www.seeedstudio.com/Grove-RGB-LED-Ring-24-WS2813-Mini-p-4297.html>

---

### 103. Grove - RGB LED (WS2813 Mini)
单颗 WS2813 Mini RGB LED，数字控制，可独立使用或级联。
<https://www.seeedstudio.com/Grove-RGB-LED-WS2813-Mini-p-4303.html>

---

### 104. Grove - RGB LED Stick (20-WS2813 Mini)
20 颗 WS2813 Mini RGB LED 条形灯，数字控制，更长显示效果。
<https://www.seeedstudio.com/Grove-RGB-LED-Stick-20-WS2813-Mini-p-4300.html>

---

### 105. Grove - OLED Display 0.96" (SSD1306)
0.96 寸 OLED 显示屏，128x64 点阵，白色，I2C 接口，低功耗，显示清晰。
<https://www.seeedstudio.com/Grove-OLED-Display-0.96-p-781.html>

---

### 106. Grove - OLED Display 0.66" (SSD1306)
0.66 寸迷你 OLED 显示屏，64x48 点阵，I2C 接口，紧凑设计，适合可穿戴。
<https://www.seeedstudio.com/Grove-OLED-Display-0.66-p-4329.html>

---

### 107. Grove - OLED Display 1.12" (SH1107)
1.12 寸 OLED 显示屏，128x128 点阵，I2C 接口，显示面积更大，适合信息显示。
<https://www.seeedstudio.com/Grove-OLED-Display-1.12-p-5011.html>

---

### 108. Grove - OLED Yellow & Blue Display 0.96" (SSD1315)
0.96 寸双色 OLED 显示屏，黄蓝双区显示，128x64 点阵，I2C 接口，适合状态显示。
<https://www.seeedstudio.com/Grove-OLED-Yellow-Blue-Display-0.96-p-4608.html>

---

### 109. Grove - RGB LED Matrix w/ Driver
RGB LED 点阵模块，集成驱动芯片，WS2813，8x8 或更大配置，适合动态显示。
<https://www.seeedstudio.com/Grove-RGB-LED-Matrix-w-Driver-p-4291.html>

---

### 110. Grove - LED Matrix Driver (HT16K33)
HT16K33 LED 驱动芯片模块，I2C 接口，可驱动 16x8 LED 矩阵，适合自定义显示。
<https://www.seeedstudio.com/Grove-LED-Matrix-Driver-HT16K33-p-4292.html>

---

### 111. Grove - I2C Motor Driver (L298P)
双 H 桥电机驱动，L298P，支持 2A 电流，I2C 接口，可控制 2 个直流电机或 1 个步进电机。
<https://www.seeedstudio.com/Grove-I2C-Motor-Driver-L298P-p-4301.html>

---

### 112. Grove - I2C Motor Driver (TB6612FNG)
双 H 桥电机驱动，TB6612FNG，1.2A 电流，I2C 接口，比 L298P 更紧凑。
<https://www.seeedstudio.com/Grove-I2C-Motor-Driver-TB6612FNG-p-4302.html>

---

### 113. Grove - MP3 V3
MP3 播放器模块，UART 接口，支持 TF 卡，可播放 MP3 音频文件，适合语音提示和音乐播放。
<https://www.seeedstudio.com/Grove-MP3-Player-V3-p-4326.html>

---

### 114. Grove - MP3 V4
MP3 播放器模块升级版，UART 接口，更好的音频处理能力。
<https://www.seeedstudio.com/Grove-MP3-Player-V4-p-4327.html>

---

### 115. Grove - Passive Buzzer
无源蜂鸣器模块，PWM 控制，音量可调，适合音效和警报提示。
<https://www.seeedstudio.com/Grove-Passive-Buzzer-p-4396.html>

---

### 116. Grove - Offline Voice Recognition Module
离线语音识别模块，支持自定义命令词，UART 接口，无需联网即可语音控制。
<https://www.seeedstudio.com/Grove-Offline-Voice-Recognition-Module-p-4465.html>

---

### 117. Grove - Speaker Plus
扬声器放大模块，D 类放大器，3W，驱动扬声器发声，适合音频输出。
<https://www.seeedstudio.com/Grove-Speaker-Plus-p-4561.html>

---

### 118. Grove - 16-Channel PWM Driver (PCA9685)
16 通道 PWM 驱动，I2C 接口，PCA9685 芯片，可控制多路舵机和 LED。
<https://www.seeedstudio.com/Grove-16-Channel-PWM-Driver-PCA9685-p-4344.html>

---

### 119. Grove - Doppler Radar (BGT24LTR11)
24GHz 多普勒雷达传感器，检测运动物体速度，模拟输出，适合运动检测和速度测量。
<https://www.seeedstudio.com/Grove-Doppler-Radar-BGT24LTR11-p-4350.html>

---

### 120. Grove - ADS1115 16-bit ADC
16 位高精度 ADC，I2C 接口，4 通道，量程 ±6.144V，适合传感器数据采集。
<https://www.seeedstudio.com/Grove-ADS1115-16-bit-ADC-p-4345.html>

---

### 121. Grove - Red LED Button
红色 LED 按钮，带 LED 指示灯，数字输出，适合状态按钮和用户界面。
<https://www.seeedstudio.com/Grove-Red-LED-Button-p-4114.html>

---

### 122. Grove - Yellow LED Button
黄色 LED 按钮，带 LED 指示灯，数字输出，适合状态按钮。
<https://www.seeedstudio.com/Grove-Yellow-LED-Button-p-4115.html>

---

### 123. Grove - Blue LED Button
蓝色 LED 按钮，带 LED 指示灯，数字输出，适合状态按钮。
<https://www.seeedstudio.com/Grove-Blue-LED-Button-p-4116.html>

---

### 124. Grove - Dual Button
双按钮模块，两个独立按钮，数字输出，适合双键输入和控制。
<https://www.seeedstudio.com/Grove-Dual-Button-p-4117.html>

---

### 125. Grove - 5-Way Switch
五向摇杆开关，模拟输出，可检测多个方向，适合游戏手柄和导航控制。
<https://www.seeedstudio.com/Grove-5-Way-Switch-p-4118.html>

---

### 126. Grove - 6-Position DIP Switch
6 位 DIP 开关，模拟输出，可用于配置设置和模式选择。
<https://www.seeedstudio.com/Grove-6-Position-DIP-Switch-p-4134.html>

---

### 127. Grove - Mech Keycap
机械键盘按键帽模块，机械轴开关，适合键盘和输入设备项目。
<https://www.seeedstudio.com/Grove-Mech-Keycap-p-4119.html>

---

### 147. Grove Beginner Kit for Arduino
Arduino 初学者套件，包含多个常用 Grove 模块和 Arduino 兼容板，适合入门学习。
<https://www.seeedstudio.com/Grove-Beginner-Kit-for-Arduino-p-4528.html>

---

### 148. Grove Beginner Kit for Arduino Education Add-on Pack
Arduino 教育版套件扩展包，配合 Beginner Kit 使用，提供更多传感器和模块。
<https://www.seeedstudio.com/Grove-Beginner-Kit-for-Arduino-Education-Add-on-Pack-p-4743.html>

---

### 149. Grove Starter Kit for Raspberry Pi Pico
Raspberry Pi Pico 入门套件，包含 Pico 板和多种 Grove 模块，适合 Pico 学习。
<https://www.seeedstudio.com/Grove-Starter-Kit-for-Raspberry-Pi-Pico-p-5126.html>

---

### 150. Grove Beginner kit for MSX0
MSX0 系列入门套件，配套 MSX0 开发板使用。
<https://www.seeedstudio.com/Grove-Beginner-kit-for-MSX0-p-5298.html>

---

### 151. Grove Creator Kit - α
创意套件 α 款，多种传感器和执行器组合，适合创意项目。
<https://www.seeedstudio.com/Grove-Creator-Kit-A-p-4795.html>

---

### 152. Grove Creator Kit - β
创意套件 β 款，不同模块组合，适合进阶创意项目。
<https://www.seeedstudio.com/Grove-Creator-Kit-B-p-4796.html>

---

### 153. Grove Creator Kit - γ
创意套件 γ 款，专业级 Grove 模块组合，适合复杂项目。
<https://www.seeedstudio.com/Grove-Creator-Kit-C-p-4797.html>

---

### 154. Grove Base Kit for Raspberry Pi
Raspberry Pi Grove 基础套件，包含 Base Hat 和多种传感器，适合树莓派项目。
<https://www.seeedstudio.com/Grove-Base-Kit-for-Raspberry-Pi-p-4020.html>

---

### 155. Grove Integrated Pressure Sensor Kit (MPX5700AP)
压力传感器套件，MPX5700AP，量程 0-700kPa，模拟输出，适合气压和液体压力检测。
<https://www.seeedstudio.com/Grove-Integrated-Pressure-Sensor-Kit-MPX5700AP-p-4259.html>

---

### 156. Grove - ORP Sensor Kit Pro
ORP（氧化还原电位）传感器套件 pro 版，水质检测，适合渔业和水处理。
<https://www.seeedstudio.com/Grove-ORP-Sensor-Kit-Pro-p-4742.html>

---

### 157. Grove Temperature and Barometer Sensor (SPA06-003)
温湿度和气压传感器模块，板载集成度高，I2C 接口。
<https://www.seeedstudio.com/Grove-Temperature-and-Barometer-Sensor-SPA06-003-p-4063.html>

---

### 161. Grove - CAN Bus Module (GD32E103)
CAN 总线模块，基于 GD32E103，CAN2.0 接口，适合汽车电子和工业控制。
<https://www.seeedstudio.com/Grove-CAN-BUS-Module-based-on-GD32E103-p-5646.html>

---

### 162. Grove Wrapper (20 Sets)
Grove 固定夹套装，20 套，模块固定和保护用。
<https://www.seeedstudio.com/Grove-Wrapper-20-Sets-p-3422.html>

---

### 163. Grove - Rivet Pack (30 PCS)
Grove 铆钉包，30 个，线束固定和组装用。
<https://www.seeedstudio.com/Grove-Rivet-Pack-30-PCS-p-3423.html>

---

### 164. Grove - 3-Axis Digital Accelerometer (LIS3DHTR)
3 轴数字加速度计，LIS3DHTR，I2C/SPI 接口，低功耗，适合运动检测和姿态测量。
<https://www.seeedstudio.com/Grove-3-Axis-Digital-Accelerometer-LIS3DHTR-p-3235.html>

---

### 165. Grove - Thermal Imaging Camera / IR Array MLX90640 55 degree
红外热成像摄像头，MLX90640，55° FOV，I2C 接口，32x24 分辨率，适合环境热分析。
<https://www.seeedstudio.com/Grove-Thermal-Imaging-Camera-IR-Array-MLX90640-55-degree-p-4349.html>

---

### 166. Grove - Female Header-Beige 4P-2.0 (600 Pcs)
4Pin Grove 母头 beige 版本，600 个散件，SMD 封装，适合批量焊接。
<https://www.seeedstudio.com/Grove-Female-Header-Beige-4P-2.0-600Pcs-p-4382.html>

---

### 167. Grove - Female Header-Beige 4P-2.0 (20 Pcs)
4Pin Grove 母头 beige 版本，20 个散件。
<https://www.seeedstudio.com/Grove-Female-Header-Beige-4P-2.0-20Pcs-p-4383.html>

---

### 168. Grove - Female Header-Beige 4P-2.0-90D (20 Pcs)
4Pin Grove 母头 90° 版本，20 个，适合水平连接。
<https://www.seeedstudio.com/Grove-Female-Header-Beige-4P-2.0-90D-20Pcs-p-4384.html>

---

### 169. Grove - Interface Multifunctional Cable (Dupont Pins)
Grove 转杜邦线多功能线缆，兼容性和灵活性强，方便连接其他开发板。
<https://www.seeedstudio.com/Grove-Interface-multifunctional-cable-compatible-with-Dupont-Pins-p-5251.html>

---

### 170. Grove Vision AI Module V1
初代 Vision AI 模块，Himax HX6537-A，OV2640 摄像头，I2C 接口，支持人脸检测和简单 AI 模型。
<https://www.seeedstudio.com/Grove-Vision-AI-Module-p-5457.html>

---

### 171. Grove Gas Sensor (BME688)
BME688 气体传感器，Bosch 芯片，集成温湿度、气压和气体检测，AI 算法支持。
<https://www.seeedstudio.com/Grove-Gas-Sensor-BME688-p-5396.html>

---

### 172. Grove Zero Starter Kit V2.0
Grove Zero 入门套件 V2.0，micro:bit 兼容，适合编程启蒙。
<https://www.seeedstudio.com/CH_Grove-Zero-Starter-Kit-V2.0-p-4708.html>

---

### 173. Grove Zero Car Kit V2.0
Grove Zero 智能车套件 V2.0，配套 micro:bit，控制电机和传感器。
<https://www.seeedstudio.com/CH_Grove-Zero-Car-Kit-V2.0-p-4709.html>

---

### 174. Grove Zero Bit Kit micro:car V2.0
micro:car 套件 V2.0，小型智能车平台，适合循线和遥控项目。
<https://www.seeedstudio.com/CH_Grove-Zero-Bit-Kit-micro-car-V2.0-p-4710.html>

---

### 175. Grove Seeed Studio Vision AI V2 Kit for ARM
Vision AI V2 专用套件，配套 ARM 开发板，edge AI 视觉应用。
<https://www.seeedstudio.com/Seeed-Studio-Vision-AI-V2-Kit-for-ARM-p-5639.html>
