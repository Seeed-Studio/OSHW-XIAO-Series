---
name: xiao-weekly-search
description: XIAO 系列硬件热门项目多源搜索与去重（含黑名单机制）。执行 GitHub + YouTube + Instructables 等多源搜索，并基于 projects.yaml + blacklist.md 去重后输出最终结果。
---

# xiao-weekly-search

从 GitHub、YouTube、Instructables、Hackster 等渠道搜索 XIAO 系列硬件项目，完成去重、信息补全、细筛，并输出可写入候选池。

---

# 🧠 全局执行原则（必须严格遵守）


## 🔒 执行纪律（强制）

### YT-1：YouTube/多源并发抓取必须严格遵循"逐条拉取→立即落盘→读文件汇总"

**禁止：** 在同一 exec 中并发多个 yt-dlp，将输出流混合后让 LLM 自行匹配 URL 与元数据。

**必须：**
1. 每条 URL 单独执行 yt-dlp
2. **立即** append 到带 URL 前缀的临时 `.tsv` 落盘文件（格式：`url|field1|field2|...`）
3. 所有 URL 抓取完毕后，**统一读取落盘文件**再汇总
4. 不在 LLM 内存/上下文缓冲中做 URL→元数据匹配

```bash
# ✅ 正确示例
for url in "${youtube_urls[@]}"; do
  result=$(yt-dlp --skip-download --print title ... "$url" 2>/dev/null)
  echo "$url|$result" >> /tmp/yt_enrich_$(date +%s).tsv
done
# 然后读取 tsv 文件做汇总
```

### SEL-1：Phase 3 必须强制自检

Phase 3 完成后（所有 URL Enrichment 完毕），在写入 enrichment_data.md **之前**：
1. 随机抽样 3 条 YouTube URL
2. 用 yt-dlp 重新拉取 metadata
3. 对比 enrichment_data 中的记录与实际值
4. 若发现任何错位（title/author/views 不匹配），整批重拉
5. 自检通过后才能写入 enrichment_data.md

### SEL-2：Phase 5 必须强制自检

Phase 5 开始前（projects.yaml 写入后），生成数据锁定报告：
1. 读取 projects.yaml 前 19 条（本次新增批次）
2. 逐条核对 board/author/title 与 enrichment_data.md 是否一致
3. 若不一致，报告 Carla 并等待修正指令
4. 确认一致后才能进入 blog 生成阶段

### SRC-1：projects.yaml 是唯一真实数据源

- **Phase 6（blog 生成）前，必须重新读取 projects.yaml**
- 禁止从 enrichment_data.md 或 LLM 内存中的旧数据生成 blog
- blog 中所有 board/author/title 字段，必须逐条对照 projects.yaml 而非历史上下文

---

## 📂 数据源

### 白名单（已收录项目）

```bash
projects.yaml
```

### 黑名单（噪声项目库）

```bash
blacklist.md
```

---

### review-notes.md（人工判断记录）

```bash
review-notes.md
```

---

## PRE-FLIGHT CHECK (MANDATORY)

Before execution starts:

The assistant MUST output:

1. Execution plan (all phases)
2. Tools to be used (explicit list)
3. Data sources (files/scripts/APIs)
4. WAIT FOR USER CONFIRMATION ("CONFIRM")

❗ Execution cannot start without confirmation

# 🚀 Phase 1 — 多源一次性搜索（禁止回查）

## ⚠️ OUTPUT CONTRACT (STRICT):

Phase 1 is a RAW DATA EXTRACTION STAGE ONLY.

FORBIDDEN:
- No analysis of relevance
- No commentary on quality
- No summarization of results
- No interpretation of "XIAO relevance"
- No evaluation of dataset quality
- No suggestions for next steps

Any analytical sentence (including "results are good/bad/low relevance") is INVALID.


## 1a. GitHub 搜索

执行以下 3 个请求（一次性执行完）：

```bash
# 1. XIAO SAMD21 / RA4M1 / Seeeduino XIAO
curl -s "https://api.github.com/search/repositories?q=(\"XIAO+SAMD21\"+OR+\"XIAO+RA4M1\"+OR+\"Seeeduino+XIAO\"+OR+\"Seeed+Studio+XIAO\")+in:readme+pushed:>{7天前的日期}+stars:>30&sort=stars&order=desc&per_page=20"

# 2. XIAO nRF / BLE / MG24 / RP2040 / RP2350
curl -s "https://api.github.com/search/repositories?q=(\"XIAO+nRF52850\"+OR+\"XIAO+nRF54L15\"+OR+\"XIAO+BLE\"+OR+\"XIAO+MG24\"+OR+\"XIAO+RP2040\"+OR+\"XIAO+RP2350\")+in:readme+pushed:>{7天前的日期}+stars:>30&sort=stars&order=desc&per_page=20"

# 3. XIAO ESP32 Series
curl -s "https://api.github.com/search/repositories?q=(\"XIAO+ESP32\"+OR+\"XIAO+ESP32S3\"+OR+\"XIAO+ESP32C3\"+OR+\"XIAO+ESP32C6\"+OR+\"XIAO+ESP32C5\")+in:readme+pushed:>{7天前的日期}+stars:>30&sort=stars&order=desc&per_page=20"
```

将3个结果合并同类项输出Markdown preview：

```md
## GitHub Raw Pool (UNFILTERED)
1. ⭐stars | repo full name | description | url 
...
```

---

## 1b. YouTube 搜索

```bash
search_youtube.py
python3 scripts/search_youtube.py
```

输出Markdown preview：

```md
## YouTube Raw Pool (UNFILTERED)
1. duration | title | description | url
...
```

---

## 1c. Instructables 搜索

使用 browser 自动化抓取 Instructables 搜索结果（只取前 20 条）：

```bash
# Step 1: Open search page (XIAO featured projects, newest first)
openclaw browser open "https://www.instructables.com/search/?q=xiao&projects=featured&sort=Newest" --label instructables_search

# Step 2: Wait for JS rendering
sleep 3

# Step 3: Extract results (up to 20)
openclaw browser snapshot --target-id instructables_search
# - Parse: project title, author, views count, url
# - Results are sorted by Newest, only take first 20
# - Scroll if needed: openclaw browser press PageDown

# Step 4: Close tab
openclaw browser close instructables_search
```

输出Markdown preview：

```md
## Instructables Raw Pool (UNFILTERED)
1. views | title | author | url
...
```

> ⚠️ Instructables 是 SPA（React），web_fetch/curl/Serper API 均无法获取实际内容，必须使用 browser 自动化。
> ⚠️ 必须关闭 tab 避免资源泄漏。

---

## 1d. Hackster 搜索

使用 browser 自动化抓取 Hackster 搜索结果（只取前 20 条）：

```bash
# Step 1: Open search page (XIAO featured projects, most recent)
openclaw browser open "https://www.hackster.io/search?q=seeed%20studio%20xiao&i=projects&project_type=featured&sort_by=most_recent" --label hackster_search

# Step 2: Wait for JS rendering
sleep 3

# Step 3: Extract results (up to 20)
openclaw browser snapshot --target-id hackster_search
# - Parse: project title, author, views, url
# - Results are sorted by most recent, only take first 20
# - Scroll if needed: openclaw browser press PageDown

# Step 4: Close tab
openclaw browser close hackster_search
```

输出Markdown preview：

```md
## Hackster Raw Pool (UNFILTERED)
1. views | title | author | url
...
```

> ⚠️ Hackster 是 SPA，web_fetch/curl/API 均无法获取实际内容，必须使用 browser 自动化。
> ⚠️ 必须关闭 tab 避免资源泄漏。

---

# 🧊 Phase 2 — 粗筛（仅去重）

## ⚠️ INFORMATION ISOLATION RULE:

Phase 2 MUST NOT use any enrichment data.
Only URL-based comparison is allowed.
Any classification or content understanding is forbidden here.
此阶段开始禁止任何网络请求，禁止类型判断，仅做 whitelist / blacklist 去重

---

## 2a. 加载去重库（只读一次）

```text

# 解析 projects.yaml：遍历该文件，提取出所有条目下 `link:` 对应的值，存入 whitelist_set
whitelist_set ← projects.yaml (link)

# 解析 blacklist.md：遍历该文件，提取出所有条目下 `- link:` 对应的值，存入 blacklist_set
blacklist_set ← blacklist.md (link)

# 新建粗筛结果缓存空间
rough_candidate_pool = []
```

---

## 2b. 粗筛逻辑（单次执行）

对所有 raw pool 执行：

* ❌ link ∈ whitelist → 已收录
* ❌ link ∈ blacklist → 已过滤历史噪声
* ✅ 其余全部进入 rough_candidate_pool

---

## 2c. 输出粗筛结果

```md
## Rough Dedup Result

- GitHub: X
- YouTube: X
- Instructables: X
- Total: X
- 粗筛列表
```

---

# 🎨 Phase 3 — Unified Enrichment

Use only `rough_candidate_pool`.

---

## Unified Output Schema

```text
name
author
image

summary_blog

board
category
year
month

programming_language
secondary_languages
framework_tool
runtime_platform

key_tech
hardware_stack
use_case

source_evidence
confidence
```

---

## Field Definitions

### Core Fields

* `name` = project title
* `author` = creator / channel / repo owner
* `image` = best available image

### Content Fields

* `summary_blog` = 2-4 sentence description

### YAML Fields

* `board` = detected XIAO model(s)
* `category` = best-fit category
* `year` = publish year / latest update year
* `month` = publish month / latest update month

### Technical Fields

* `programming_language` = primary coding language
  (C++, Python, MicroPython, Rust, JavaScript...)

* `secondary_languages` = additional meaningful languages

* `framework_tool` = development tools / frameworks
  (Arduino IDE, PlatformIO, MicroPython, LVGL, TensorFlow Lite...)

* `runtime_platform` = system/runtime layer
  (ESP-IDF, Zephyr, Matter, Home Assistant...)

### Feature Fields

* `key_tech` = main technical highlights
  (BLE, Wi-Fi, LoRa, TinyML, MQTT, Voice Recognition...)

* `hardware_stack` = major hardware modules used
  (Camera, OLED, Relay, IMU, Servo, Battery...)

* `use_case` = real application scenario
  (Smart Home, Robotics, Wearable, Monitoring...)

### Validation Fields

* `source_evidence` = where evidence was found
* `confidence` = high / medium / low

缺失字段 = `null`，不猜测。

---

## 各数据源 Enrichment 方法

| 数据源 | 方法 | 原因 |
|--------|------|------|
| GitHub | Schema-First | API 数据本身已结构化，字段与 schema 一一对应 |
| YouTube | Schema-First | yt-dlp metadata 字段固定，与 schema 对应 |
| Instructables | Scan-First + 逐个匹配 | SPA 页面结构复杂，需先扫描再映射 |
| Hackster | Scan-First + 逐个匹配 | 同上，DOM 结构不可预测 |

---

## 3a. GitHub Enrichment（Schema-First）

从 repo metadata + README 提取字段，映射到 Unified Schema。

---

## 3b. YouTube Enrichment（Schema-First）

使用 yt-dlp 提取 metadata，直接映射到 Unified Schema。

```bash
yt-dlp --skip-download \
  --print title --print uploader --print thumbnail \
  --print duration --print view_count --print upload_date \
  "{video_url}" 2>/dev/null

# description 单独获取
yt-dlp --skip-download --print description "{video_url}" 2>/dev/null
```

> ⚠️ 字幕 transcript 需要完整 JS runtime，metadata 直出已够用。

---

## 3c. Instructables Enrichment（Scan-First + 逐个匹配）

每个 URL 单独处理：打开页面 → 扫描全文 → 提取字段 → 映射到 Unified Schema → 关闭 tab。

### 工作流程

```bash
# 对每个 Instructables URL 执行：

# Step 1: 打开页面
openclaw browser open "{url}" --label instructables_{index}

# Step 2: 等待 JS 渲染
sleep 3

# Step 3: 扫描全文
openclaw browser snapshot --target-id instructables_{index}
# 从 snapshot 中提取所有可用字段

# Step 4: 映射到 Unified Schema
# name      ← heading (h1)
# author    ← 作者链接文本
# image     ← 主图 URL
# summary_blog ← 介绍段落（2-4句）
# board     ← XIAO 型号（正文/Supplies 中搜索）
# category  ← 分类标签
# year/month← 发布日期（"YYYY-MM-DD" 格式）
# programming_language ← 代码语言（正文/步骤中搜索）
# hardware_stack ← 硬件清单（Supplies 区块）
# key_tech ← 核心技术关键词（BLE/Wi-Fi/LoRa/MQTT 等）
# use_case ← 应用场景

# Step 5: 关闭 tab
openclaw browser close instructables_{index}
```

### 页面区块参考（Instructables 结构固定）

| 区块 | snapshot 中的 ref | 提取内容 |
|------|-----------------|---------|
| 标题 | `heading level=1` | name |
| 作者 | heading 附近的 link | author |
| 发布日期 | `generic "YYYY-MM-DD"` | year, month |
| 主图 | heading 附近的 link[url 含 .jpg] | image |
| 介绍 | `paragraph` 在 heading 之后 | summary_blog |
| Supplies | `heading "Supplies"` 之后 | hardware_stack |
| Steps | `heading "Step N:"` 之后 | key_tech, programming_language |

### 注意事项

- ⚠️ 必须关闭 tab 避免资源泄漏
- ⚠️ 页面加载失败时，confidence = `low`，注明 `content not accessible`
- ⚠️ 先扫描再映射，不强求每个字段都有值

---

## 3d. Hackster Enrichment（Scan-First + 逐个匹配）

Hackster 项目页同为 SPA，流程与 Instructables 类似。

### 工作流程

```bash
# 对每个 Hackster URL 执行：

# Step 1: 打开页面
openclaw browser open "{url}" --label hackster_{index}

# Step 2: 等待 JS 渲染
sleep 3

# Step 3: 扫描全文
openclaw browser snapshot --target-id hackster_{index}
# 从 snapshot 中提取所有可用字段

# Step 4: 映射到 Unified Schema
# name      ← h1 heading
# author    ← 作者名/链接文本
# image     ← 主图 URL（og:image 或标题区图片）
# summary_blog ← 介绍段落
# board     ← XIAO 型号（正文中搜索）
# category  ← 分类标签
# year/month← 发布日期（"Published YYYY-MM-DD" 格式）
# programming_language ← 代码语言
# hardware_stack ← "Things used in this project" 表格
# key_tech ← 核心技术关键词
# use_case ← 应用场景

# Step 5: 关闭 tab
openclaw browser close hackster_{index}
```

### 页面区块参考（Hackster 结构固定）

| 区块 | snapshot 中的特征 | 提取内容 |
|------|-----------------|---------|
| 标题 | `heading level=1` | name |
| 作者 | `link` 指向 /{username} | author |
| 发布日期 | `generic "Published YYYY-MM-DD"` | year, month |
| 主图 | article 区内的 img | image |
| 介绍 | heading 后的 paragraph | summary_blog |
| Hardware 表格 | `table` 含 "Things used" | hardware_stack |

### 注意事项

- ⚠️ 必须关闭 tab
- ⚠️ 部分页面有嵌入式视频/iframe，忽略即可
- ⚠️ 页面加载失败时，confidence = `low`

---

## Output Rule

All candidates must return the same schema.
Missing fields = `null`
Do not guess unsupported claims.

写入：`enrichment_data.md`（可不批准直接写入）



# 🔍 Phase 4 — 细筛（类型筛选 + 最终候选池）

---

## 4a. 加载人工判断库（只读一次）

遍历review-notes.md文件，学习之前判断失误的经验

## 4b. 类型筛选（仅基于enrichment_data.md数据）

❌ 排除：
1. SDK/Driver：提供被别人调用的接口库，不是独立项目
2. 收集型/课程型：标题含数字规律或"collection"的合集，不是单一项目
3. 虚假引用：README仅在兼容列表/feature list中提到XIAO，无代码/硬件
4. 噪音：搜索命中但无真实 XIAO 使用

✅ 保留（其余全部）：
- 任何有具体XIAO使用示例的，不管项目多通用
- 任何以XIAO为主控的硬件产品/扩展板/PCB设计/集成产品
- 任何基于XIAO的软件应用（网络协议、无线电、嵌入式Linux风格应用）
- 不管项目是嵌入式/软件/游戏/任何形态
- 不管我认为它是否"配得上"叫XIAO项目
- 只要README有XIAO真实引用，就保留

---

## 4c. 输出去重报告

```md
## Dedup Report

### GitHub
- ❌ reason
- ✅ keep reason

### YouTube
- ❌ reason
- ✅ keep reason

### Instructables
- ❌ reason
- ✅ keep reason
```
---

## 4d. review-notes.md更新（更新人工判断记录）

Carla可以指出误判项目，修正 category / board / author，指出某类项目应保留或应淘汰，更新review-notes.md文件。

review-notes.md

用途：

* Carla 指出误判项目
* Carla 修正 category / board / author
* Carla 指出某类项目应保留或应淘汰
* Carla 修改筛选标准

输出：

```md
## Review Notes Preview

### YYYY-MM-DD

- Project: xxx
  Link: xxx
  AI Decision: Reject
  Carla Correction: Keep
  Reason: Real XIAO project with valid hardware usage

- Project: xxx
  AI Category: Tools
  Carla Correction: Mechanical Keyboard
```

```text
append manual corrections / Carla decisions
```


---

## 4e. 黑名单新增缓存与最终候选池（锁定）

```md
GitHub: X
YouTube: X
Instructables: X
Total: X
```

```text
# 新增黑名单缓存
new_blacklist_buffer ← 本阶段被淘汰项目

# 新增FINAL CANDIDATE POOL (LOCKED)
final_candidate_pool ← 最终候选池项目
```

⚠️ 从此之后：

❌ 禁止重新筛选
❌ 禁止重新 enrichment
❌ 禁止回查数据

---


# 🧾 Phase 5 — 黑白名单文件写入（需 Carla 批准）

## ⚠️ 未获得 Carla 明确批准前，只输出预览，不得写文件

---
## 5a. blacklist.md（历史噪声库）

输出：

```md
## Blacklist Updates (NEW)
- link: "淘汰项目 URL"
  reason: "淘汰理由简述"
```

执行：

```text
blacklist.md += new_blacklist_buffer
```

---


---
## 5b. projects.yaml（最终候选池写入预览）

基于 enrichment_data.md 数据，输出（必须使用 projects.yaml 标准格式）,可包含多个条目。：

```yaml
# ========== 添加新项目模板 / Template for New Projects ==========
#
# - name:
#     en: "Project Name"
#     zh: "项目名称"
#   description:
#     en: "Brief description of the project"
#     zh: "项目简介"
#   board: "XIAO Model"
#   category:
#     en: "Category"
#     zh: "分类"
#   year: 2025
#   month: 1
#   author:
#     en: "Author Name"
#     zh: "作者名称"
#   author_type: "GitHub"
#   link: "Project URL"
#   image: ""


# ========== Board Options / 型号选项 ==========
# XIAO ESP32-S3, XIAO ESP32-S3 Sense, XIAO ESP32-C3, XIAO ESP32-C6, XIAO ESP32-C5
# XIAO nRF52840, XIAO nRF52840 Sense, XIAO nRF52840 Micro
# XIAO RP2040, XIAO RP2350, XIAO SAMD21, XIAO RA4M1
# XIAO MG24, XIAO MG24 Sense


# ========== Category Options / 分类选项 ==========
# en: Wearables, Robotics, Smart Home, Healthcare, Power Management
# AI Gadget, Tools & Accessories, Telecommunication, Mechanical Keyboard, LED Lighting
# zh: 可穿戴, 机器人, 智能家居, 健康护理, 电源管理, AI Gadget, 工具配件, 通信, 机械键盘, LED 灯光


# ========== Author Type / 来源平台 ==========
# GitHub, YouTube, Hackster, Instructables, Hackaday, Web

```

新增位置在开头`projects:` 字段之后, 加上开头：

```yaml
  # ========== YYYY-MM-DD Community Projects ==========
  # Source: xiao-weekly-search(日期)
```

执行：
```text
projects.yaml += final_candidate_pool

```

---

## 执行顺序（批准后）

1. 写入 blacklist.yaml
2. 写入 projects.yaml

---

获得 Carla 明确批准后方可执行写入。

# Phase6 —— blog 文章写作

## ⚠️ 未获得 Carla 明确批准前，只输出预览，不得写文件


基于 enrichment_data.md 数据，参考 blog_reference.md 风格，根据最终候选池名单撰写本周英文博客，内容包括：

**文章结构：**
1. **标题** — `# XIAO Community Projects Weekly`，附项目数量和日期
2. **简介** — 一段话概括本周亮点 + 分类标签
3. **项目列表** — 每个项目独立区块，包含：
   - **项目名 + 作者**（粗体）
   - **项目图片链接**（如果有的话）
   - **项目描述**（2~4 sentence project description with useful technical details, application scenario, or hardware setup.  
Bold keywords such as **XIAO Board**, **Arduino**, **PlatformIO**, **Python**, **BLE**, **Wi-Fi**, **LoRa**, **TinyML** if used.）
   - **Hardware Recommendation**：
      - 每个 Hardware Recommendation 的 XIAO 型号链接，必须来自 XIAO_selection.md 的 Board Selection Table
      - 每个 Expansion 产品链接，必须来自 XIAO_selection.md 的 ## Seeed Studio XIAO Expansion Board Products 区块
      - 每个 Grove 产品链接，必须来自 XIAO_selection.md 的 ## Grove Ecosystem Products 区块
      - 禁止凭记忆/印象填写，必须在写作时逐项对照文件确认
   - **项目链接**
4. **Board Selection Guide** — XIAO 全系列参数对比表格

**每条项目的 Markdown 格式：**
```md
## [项目名] by [作者]

[项目图片链接]（如果有的话）

[描述段落]

**Hardware Recommendation**
- **XIAO:** [名称](链接)
- **Expansion:** [名称](链接) 或 null
- **Grove Ecosystem:** [名称](链接) ，···可推荐多个 或 null

[View project](项目链接)
```

**风格特点：**
- 描述用一句话定位项目亮点，再展开功能
- Hardware 部分固定三项：XIAO + Expansion + Grove（无可填 null）
- 链接统一用 Markdown 短链接格式
- 无需额外评分或排名

---

获得 Carla 明确批准后方可执行覆盖 blog_reference.md 原有内容并写入新博客内容。