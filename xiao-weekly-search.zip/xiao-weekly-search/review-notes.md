# Review Notes

## 2026-04-16

- Project: Arduino GFX
  AI Decision: Keep
  Carla Correction: Reject
  Reason: SDK，显示库

- Project: TinyGo Bluetooth
  AI Decision: Keep
  Carla Correction: Reject
  Reason: SDK，蓝牙 API 库

- Project: OpenDeck
  AI Decision: Keep
  Carla Correction: Reject
  Reason: XIAO 仅举例兼容，无实际使用示例

- Project: SSCMA-Micro
  AI Decision: Keep
  Carla Correction: Reject
  Reason: SDK，官方也要淘汰

- Project: passionateSandy2004/ShellOS---OS-made-Just-For-ESP32-Boards
  AI Decision: Reject
  Carla Correction: Keep
  Reason: XIAO 占比高，ESP32 OS 项目

- Project: usetrmnl/larapaper
  AI Decision: Reject
  Carla Correction: Keep
  Reason: XIAO 7.5" ePaper Panel 是集成产品

- Project: gkoh/pico-cec
  AI Decision: Reject
  Carla Correction: Keep
  Reason: 能 build XIAO 说明跑起来，有详细 XIAO 示例

## 2026-04-28

- Project: tinygo-org/tinygo
  AI Decision: Keep
  Carla Correction: Reject
  Reason: 编译器通常不在项目范围内

- Project: colonelpanichacks/Sky-Spy
  AI Decision: Reject
  Carla Correction: Keep
  Reason: XIAO 含量很高，甚至就是用 XIAO 做的

- Project: iandol/opticka
  AI Decision: Reject
  Carla Correction: Keep
  Reason: 适合用于 XIAO 的工具也算项目，工具不再排除范围外

- Project: nanoframework/nanoFirmwareFlasher
  AI Decision: Reject (正确)
  Carla Correction: Confirm Reject
  Reason: 工具类但无明确 XIAO 提及

- Project: Meshtastic Has a Problem… (YouTube)
  AI Decision: Reject
  Carla Correction: Keep
  Reason: Meshtastic 是软件层面，XIAO 是硬件层面，两者不冲突

- Project: Arduino MKR Connector Carrier (YouTube)
  AI Decision: Reject (正确)
  Carla Correction: Confirm Reject
  Reason: Arduino MKR 主题与 XIAO 主题冲突

## 2026-05-18

- Project: Building a Lightweight Curved E-Ink Smartwatch
  AI Decision: Reject
  Carla Correction: Keep
  Reason: Seeed Studio nRF52840 Sense = XIAO nRF52840，Carla 人工确认
