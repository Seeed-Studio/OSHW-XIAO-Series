# Enrichment Data — xiao-weekly-search 2026-05-15

---

## 1. The Next Holiday — Smart E-Paper Panel

**Source:** https://www.hackster.io/etolocka/the-next-holiday-0b68b4

```
name: The Next Holiday — Smart E-Paper Panel
author: etolocka
image: null
summary_blog: A smart e-paper display panel that shows how many days are left until the next public holiday. Built around the Seeed Studio XIAO ESP32-S3 Plus module with a 5.83-inch monochrome e-paper display (EE04 controller board). The system fetches the current time from an NTP server, retrieves public holiday data from the Nager.date free API (covering 100+ countries), calculates the nearest holiday, and displays the countdown on the low-power e-paper screen. Only consumes power during screen refreshes, making it ideal for always-on information displays. RTC backup via capacitor maintains time briefly.
board: XIAO ESP32-S3
category: Smart Home
year: 2026
month: 4
programming_language: Arduino (C++)
secondary_languages: null
framework_tool: Arduino IDE, Seeed_GFX library
runtime_platform: null
key_tech: E-Paper Display, NTP, Wi-Fi, REST API, RTC
hardware_stack: XIAO ESP32-S3 Plus (EE04 E-Paper Board), 5.83" monochrome e-paper display
use_case: Smart Home Information Display
source_evidence: Hackster.io project page (browser snapshot)
confidence: high
```

---

## 2. ESP32-C6 Garage Remote

**Source:** https://www.reddit.com/r/esp32/comments/1sq1b1k/esp32c6_garage_remote/

```
name: ESP32-C6 Garage Remote
author: Unknown (Reddit user)
image: null
summary_blog: A DIY garage door remote built using the ESP32-C6 microcontroller, allowing remote control of a garage door via Wi-Fi or BLE. The project leverages the ESP32-C6's wireless capabilities to create a custom garage remote solution.
board: XIAO ESP32-C6
category: Smart Home
year: 2025
month: null
programming_language: null
secondary_languages: null
framework_tool: null
runtime_platform: null
key_tech: Wi-Fi, BLE, Home Automation
hardware_stack: XIAO ESP32-C6
use_case: Smart Home
source_evidence: Reddit r/esp32 post
confidence: low
```

---

## 3. Now Playing Display — macOS Menu Bar to ESP32-C6 Round Display

**Source:** https://www.gxlabs.co/now-playing/

```
name: Now Playing Display
author: gxlabs
image: https://www.gxlabs.co/now-playing/ (product page, no image in text)
summary_blog: A macOS menu bar app that streams currently playing media info (album art, track name, progress) to a USB-connected ESP32-C6 with a round display. The Mac app reads now-playing metadata via the MediaRemoteAdapter framework and pushes RGB565 artwork to the device over USB serial. The ESP32-C6 with a 240x240 GC9A01A round display shows the album art, track info, and progress bar. Supports Apple Music, Spotify, and other macOS media apps. Touch controls on the display send prev/play-pause/next back to the Mac.
board: XIAO ESP32-C6
category: Tools & Accessories
year: 2025
month: null
programming_language: Python (macOS app), C (ESP32 firmware)
secondary_languages: null
framework_tool: ESP-IDF, Python (py2app)
runtime_platform: macOS 13+, ESP-IDF
key_tech: USB Serial, I2S (display), MediaRemote framework
hardware_stack: XIAO ESP32-C6, Seeed Round Display for XIAO (GC9A01A 240x240)
use_case: Desktop Gadget / Media Companion
source_evidence: gxlabs.co project page + GitHub repo
confidence: high
```

---

## 4. How to Make 3D Printed Spy Car at Home | Spy Camera Car | ESP32 CAM | DIY Robot

**Source:** https://www.youtube.com/watch?v=Du1UvHnD-ZM

```
name: 3D Printed Spy Car with ESP32 CAM
author: Simple Circuits
image: https://i.ytimg.com/vi/Du1UvHnD-ZM/maxresdefault.jpg
summary_blog: A DIY spy camera car built using an ESP32-CAM module in a custom 3D-printed chassis. The project demonstrates how to create a compact, concealable robot vehicle capable of live video streaming for surveillance or exploration purposes. Features include Wi-Fi connectivity for remote viewing and control, a 3D-printed body for a clean aesthetic, and straightforward assembly suitable for makers.
board: ESP32-CAM (ESP32 + camera module)
category: Robotics
year: 2026
month: 4
programming_language: Arduino (C++)
secondary_languages: null
framework_tool: Arduino IDE, ESP32-CAM libraries
runtime_platform: null
key_tech: Wi-Fi, Camera, Live Streaming, robotics
hardware_stack: ESP32-CAM module, 3D-printed chassis, motors
use_case: Surveillance Robot
source_evidence: YouTube video (Simple Circuits)
confidence: medium
```

---

## 5. $30 FPV RC Car with XIAO ESP32-S3 Sense

**Source:** https://www.hackster.io/news/this-30-project-puts-you-in-the-driver-s-seat-of-an-rc-car-0e39a66f5f03

```
name: $30 FPV RC Car with XIAO ESP32-S3 Sense
author: Nick Bild (via Hackster News / Simple Circuits project)
image: null
summary_blog: A budget first-person-view RC car built for under $30 using the Seeed Studio XIAO ESP32-S3 Sense board, which combines processing and a camera module on one compact board. The car creates its own Wi-Fi hotspot; users connect via smartphone or laptop browser to view live video and control movement in real time. Four N20 gear motors provide 4WD capability, driven by DRV8838 motor drivers. Power comes from a 3.7V LiPo with TP4056 charging and a 5V boost converter. The chassis is 3D-printed in nylon with TPU tires.
board: XIAO ESP32-S3 Sense
category: Robotics
year: 2026
month: null
programming_language: Arduino (C++)
secondary_languages: null
framework_tool: Arduino IDE
runtime_platform: null
key_tech: Wi-Fi, FPV Camera, Web UI, Motor Control
hardware_stack: XIAO ESP32-S3 Sense, N20 gear motors (x4), DRV8838 motor drivers (x2), 3.7V LiPo, TP4056, boost converter, 3D-printed nylon/TPU chassis
use_case: FPV Robotics / RC Vehicle
source_evidence: Hackster.io news article
confidence: high
```

---

## 6. World's Smallest Joystick Remote Control

**Source:** https://www.instructables.com/Worlds-Smallest-Joystick-Remote-Control/

```
name: World's Smallest Joystick Remote Control
author: Markus Opitz
image: https://content.instructables.com/F0Y/VIRQ/MM59J7YF/F0YVIRQMM59J7YF.jpg
summary_blog: A DIY joystick remote control claimed to be the world's smallest, built with the XIAO ESP32-C6 (or C3/C5) and ESP-NOW protocol for 2.4GHz wireless communication. Achieves up to 300m range with antennas — suitable for RC vehicles, robots, pan-tilt cameras, and garage gate control. Features a "Five Direction Navigation Button Module" joystick, 100mAh LiPo battery with on-board USB charging, and compact 3D-printed or simple housing. Arduino programmed with direction debouncing logic and configurable receiver MAC address.
board: XIAO ESP32-C6
category: Tools & Accessories
year: 2026
month: null
programming_language: Arduino (C++)
secondary_languages: null
framework_tool: Arduino IDE
runtime_platform: null
key_tech: ESP-NOW, 2.4GHz Wireless, Joystick Control, Low Power
hardware_stack: XIAO ESP32-C6 (or C3/C5) with antenna, mini joystick (KY-023 or Five-Direction module), 100mAh LiPo battery, slide switch, 3D-printed housing
use_case: Remote Control / RC Vehicles / Robotics
source_evidence: Instructables page (browser snapshot)
confidence: high
```

---

## 7. EW26 Conference LinkedIn Post

**Source:** https://www.linkedin.com/posts/makahernandez_ew26-ugcPost-7436329589875830784-uNOY

```
name: EW26 Conference Project Showcase
author: Makahernandez
image: null
summary_blog: A LinkedIn post about an EW26 (possibly Embedded World 2026) conference project involving Seeed Studio XIAO hardware. Details unavailable due to LinkedIn access restrictions.
board: Unknown (possibly XIAO series)
category: null
year: 2026
month: null
programming_language: null
secondary_languages: null
framework_tool: null
runtime_platform: null
key_tech: null
hardware_stack: null
use_case: null
source_evidence: LinkedIn post (content not accessible)
confidence: low
```

---

## 8. ESP32 Guide 2026 — DroneBot Workshop

**Source:** https://www.youtube.com/watch?v=CfIjInYch7U

```
name: ESP32 Guide 2026
author: DroneBot Workshop
image: https://i.ytimg.com/vi/CfIjInYch7U/maxresdefault.jpg
summary_blog: A comprehensive 2026 guide to the entire ESP32 microcontroller family by DroneBot Workshop. Covers 11 ESP32 variants and dozens of development boards from manufacturers including Adafruit, SparkFun, Seeed Studio, Arduino, Waveshare, LilyGo, and Espressif. The article and video help makers select the right ESP32 chip and board for their specific project needs, covering all variants from original ESP32 through ESP32-H2, ESP32-C6, ESP32-C5, ESP32-S3, and newer models.
board: Multiple (ESP32 family overview, includes XIAO ESP32-S3, ESP32-C3, ESP32-C5, ESP32-C6)
category: Tools & Accessories
year: 2026
month: 3
programming_language: null
secondary_languages: null
framework_tool: null
runtime_platform: null
key_tech: Wi-Fi, BLE, Zigbee, Thread, ESP32 family overview
hardware_stack: Multiple ESP32 boards including Seeed Studio XIAO series
use_case: Education / Board Selection Guide
source_evidence: YouTube + DroneBot Workshop article
confidence: medium
```

---

## 9. Turn Your Hot Wheels into Art: Smart 3D Printed F1 Display 1:64

**Source:** https://youtu.be/WDzPgKbUWAY

```
name: Smart Hot Wheels F1 Display 1:64
author: gokux
image: https://i.ytimg.com/vi/WDzPgKbUWAY/maxresdefault.jpg
summary_blog: A smart display project that turns Hot Wheels 1:64 scale cars into rotating art pieces with electronic features. The build incorporates an ESP32-controlled rotating display platform, possibly with lighting effects and smart home integration for car collectors and enthusiasts.
board: ESP32 (specific model unknown)
category: Tools & Accessories
year: 2026
month: 3
programming_language: null
secondary_languages: null
framework_tool: null
runtime_platform: null
key_tech: Motors, Display, Smart Home
hardware_stack: ESP32, 3D-printed display platform
use_case: Collectibles Display
source_evidence: YouTube video (gokux)
confidence: low
```

---

## 10. Desktop Companion Robot

**Source:** https://www.instructables.com/Desktop-Companion-Robot

```
name: Desktop Companion Robot
author: Shahbaz Hashmi Ansari
image: null
summary_blog: A desktop companion robot powered by Arduino/ESP32 with an OLED "Doodle Eyes" display face showing expressions and animated eye movements. Connects to Wi-Fi and displays the assigned IP address on screen. Features an interactive web interface for remote control and communication. The robot has a 3D-printed or custom chassis designed for desktop use, with servo-based facial features for expressive interactions.
board: XIAO ESP32 (variant unspecified)
category: Robotics
year: 2026
month: 2
programming_language: Arduino (C++)
secondary_languages: null
framework_tool: Arduino IDE, SSD1306 OLED library
runtime_platform: null
key_tech: Wi-Fi, OLED Display, Animated UI, Web Interface, Servo Control
hardware_stack: XIAO ESP32 (unspecified variant), SSD1306 OLED display (128x64), Wi-Fi connectivity, 3D-printed chassis, servo motors for facial features
use_case: Desktop Companion / Interactive Robot
source_evidence: Instructables page (browser snapshot) + GitHub repo
confidence: medium
```

---

## 11. Building a Lightweight Curved E-Ink Smartwatch

**Source:** https://www.instructables.com/Building-a-Lightweight-Curved-EInk-Smartwatch/

```
name: Building a Lightweight Curved E-Ink Smartwatch
author: Selbyc
image: https://content.instructables.com/FOT/3ARP/MNDMJX4W/FOT3ARPMNDMJX4W.jpg
summary_blog: A rugged, comfortable, and highly hackable e-ink smartwatch built around the Seeed Studio XIAO nRF52840 Sense and a 2.9-inch Waveshare flexible e-ink display. The project explores flexible PCB design, ultra-low power operation, and sunlight-readable UI. Features 9-axis IMU (LSM9DS1), gesture sensor (APDS-9500), heart rate/SpO2 (MAX30102, early prototypes), RTC (RV-3028-C7), and GPS (MAX-M10S, early prototypes). Powered by a 400mAh LiPo battery with an AP2127K-1.8 regulator. The watch prioritizes battery life and readability over bright screens — no recharging anxiety.
board: XIAO nRF52840 Sense
category: Wearables
year: 2026
month: 3
programming_language: Arduino (C++)
secondary_languages: null
framework_tool: Arduino IDE, custom flex PCB design
runtime_platform: null
key_tech: E-Ink Display, BLE, 9-axis IMU, Gesture Detection, Low Power, Flexible PCB
hardware_stack: XIAO nRF52840 Sense, 2.9" Waveshare flexible e-ink display, LSM9DS1 9-axis IMU, APDS-9500 gesture sensor, RV-3028-C7 RTC, AP2127K-1.8 regulator, 400mAh LiPo battery, custom flex PCB
use_case: Wearable / Smartwatch
source_evidence: Instructables page (browser snapshot)
confidence: high
```

---

## 12. Arduino BIG OLED Display (256x64px SSD1322)

**Source:** https://www.youtube.com/watch?v=EEmuondHHyY

```
name: Arduino BIG OLED Display — 256x64 SSD1322
author: upir
image: https://i.ytimg.com/vi/EEmuondHHyY/maxresdefault.jpg
summary_blog: A tutorial on connecting and programming a large 256x64 pixel OLED display using the SSD1322 driver with Arduino UNO. The video covers hardware wiring (I2C/SPI), library setup (u8g2), and displaying graphics and text on the wide OLED panel. Seeed Studio XIAO ESP32S3 appears only as an affiliate product link in the description — it is NOT used in this project.
board: Arduino UNO (XIAO not used — only affiliate link in description)
category: LED Lighting
year: 2026
month: 2
programming_language: Arduino (C++)
secondary_languages: null
framework_tool: Arduino IDE, u8g2 OLED library
runtime_platform: null
key_tech: OLED Display, I2C/SPI, Graphics
hardware_stack: Arduino UNO, 256x64 SSD1322 OLED display
use_case: Display / Information Panel
source_evidence: YouTube video (upir)
confidence: low
# NOTE: XIAO appears only as affiliate link, not used in actual project — noise candidate
```

---

## 13. ESP32 Matter Tutorial #1 — Smart Bulb with XIAO ESP32 C6

**Source:** https://www.youtube.com/watch?v=_TGsAgF8L88

```
name: ESP32 Matter Tutorial #1 — Smart Bulb with XIAO ESP32 C6
author: techiesms
image: https://i.ytimg.com/vi/_TGsAgF8L88/maxresdefault.jpg
summary_blog: Episode 1 of the ESP32 Matter Series demonstrating how to build a Matter-enabled smart bulb using the XIAO ESP32-C6 board and Arduino IDE. The video explains the Matter protocol fundamentals — an open smart home standard enabling device compatibility across Alexa, Google Home, and Apple HomeKit ecosystems. Hardware setup, ESP32 board installation in Arduino IDE, and a live demo are covered. The XIAO ESP32-C6 provides Wi-Fi 6 connectivity needed for the Matter protocol.
board: XIAO ESP32-C6
category: Smart Home
year: 2026
month: 2
programming_language: Arduino (C++)
secondary_languages: null
framework_tool: Arduino IDE, ESP32 board package
runtime_platform: Matter protocol (smart home standard)
key_tech: Matter, Wi-Fi 6, Smart Home, MQTT
hardware_stack: XIAO ESP32-C6, smart bulb (hardware demo)
use_case: Smart Home / Matter Device
source_evidence: YouTube video + GitHub code repo (techiesms/ESP32-MATTER-Series-Codes)
confidence: high
```

---

## 14. Why I'm Building AI Cameras

**Source:** https://www.youtube.com/watch?v=dS8DjZji6s8

```
name: Why I'm Building AI Cameras
author: Founders, Inc.
image: https://i.ytimg.com/vi/dS8DjZji6s8/maxresdefault.jpg
summary_blog: A discussion/presentation on the motivation and engineering behind building AI-powered camera systems. The video explores the use of ESP32-S3 and similar microcontrollers for on-device AI inference at the edge. Topics include computer vision, TinyML, and deploying AI models on resource-constrained hardware for applications like object detection, face recognition, or surveillance.
board: ESP32-S3
category: AI Gadget
year: 2026
month: 1
programming_language: null
secondary_languages: null
framework_tool: TinyML, Edge AI frameworks
runtime_platform: null
key_tech: AI, Computer Vision, TinyML, Edge Computing
hardware_stack: ESP32-S3 (camera module implied)
use_case: AI Vision / Surveillance
source_evidence: YouTube video (Founders, Inc.)
confidence: medium
```

---

## 15. Xiao ESP32C3 & ESP32C6 Game Changer! Development Board Review

**Source:** https://www.youtube.com/watch?v=NAq0QlphLSE

```
name: XIAO ESP32C3 & ESP32C6 Review — Game Changer!
author: Electronic Clinic
image: https://i.ytimg.com/vi/NAq0QlphLSE/maxresdefault.jpg
summary_blog: A detailed review and tutorial on the Seeed Studio XIAO ESP32-C3 and XIAO ESP32-C6 development boards, highlighting why these compact boards are game-changers for IoT and embedded projects. The video covers specs, pinouts, wireless capabilities (BLE 5.0 for C3, Wi-Fi 6 for C6), power consumption, and practical demos including GPIO usage, sensor interfacing, and comparison with other ESP32 variants. A great resource for makers deciding which XIAO board to use.
board: XIAO ESP32-C3, XIAO ESP32-C6
category: Tools & Accessories
year: 2026
month: 2
programming_language: Arduino (C++) or MicroPython
secondary_languages: null
framework_tool: Arduino IDE, MicroPython
runtime_platform: null
key_tech: Wi-Fi 6 (C6), BLE 5.0, RISC-V, IoT
hardware_stack: XIAO ESP32-C3, XIAO ESP32-C6
use_case: IoT Development / Board Review
source_evidence: YouTube video (Electronic Clinic)
confidence: medium
```

---

## 16. XIAO ESP32-C5 Explained — Dual Band Wi-Fi 6 ESP32 in a Tiny Board

**Source:** https://www.youtube.com/watch?v=SRNlok6IJ-U

```
name: XIAO ESP32-C5 Explained — Dual Band Wi-Fi 6 Review
author: Electronic Clinic
image: https://i.ytimg.com/vi/SRNlok6IJ-U/maxresdefault.jpg
summary_blog: An in-depth review of the Seeed Studio XIAO ESP32-C5, highlighting its dual-band Wi-Fi 6 capability as a standout feature in the XIAO lineup. The video covers the ESP32-C5's specs (RISC-V processor, 240MHz clock, 384KB SRAM, 8MB SPI flash), power consumption, GPIO, and practical tests of Wi-Fi 6 performance. Demonstrates why the XIAO ESP32-C5 is ideal for Wi-Fi 6 IoT projects requiring faster throughput and better efficiency than 2.4GHz-only boards.
board: XIAO ESP32-C5
category: Tools & Accessories
year: 2026
month: 2
programming_language: Arduino (C++) or MicroPython
secondary_languages: null
framework_tool: Arduino IDE, MicroPython
runtime_platform: null
key_tech: Wi-Fi 6 (5GHz support), BLE 5.0, RISC-V, IoT
hardware_stack: XIAO ESP32-C5
use_case: IoT Development / Wi-Fi 6 Projects
source_evidence: YouTube video (Electronic Clinic)
confidence: medium
```

---

## 17. I Built an AI Desk Buddy with ESP32 (Xiaozhi + Custom Face UI)

**Source:** https://www.youtube.com/watch?v=aDaSp6zaqWM

```
name: AI Desk Buddy — ESP32 with Xiaozhi Firmware and Custom Animated Face
author: Tech Talkies
image: https://i.ytimg.com/vi/aDaSp6zaqWM/maxresdefault.jpg
summary_blog: An interactive AI desk companion built with the Seeed Xiao ESP32-S3 running the Xiaozhi firmware for voice AI capabilities. The project replaces the default Xiaozhi emoji UI with a custom animated robot face on a 128x64 OLED display featuring blinking, idle movement, listening side-eye animation, and real-time mouth synchronization with speech. The build uses an I2S microphone for wake word detection and a MAX98357A I2S amplifier for audio output. Supports OTA firmware updates and runs entirely on ESP32 hardware with no cloud services required for core functionality.
board: XIAO ESP32-S3
category: AI Gadget
year: 2026
month: 2
programming_language: C/C++ (ESP-IDF), Xiaozhi firmware
secondary_languages: null
framework_tool: ESP-IDF, Xiaozhi AI firmware
runtime_platform: Xiaozhi (open-source voice AI platform)
key_tech: Voice AI, I2S Audio, OLED Display, Wake Word, OTA Updates
hardware_stack: XIAO ESP32-S3, MAX98357A I2S amplifier, I2S MEMS microphone, 128x64 OLED display, 4Ω 3W speaker
use_case: AI Companion / Desktop Gadget
source_evidence: YouTube video (Tech Talkies) + video description
confidence: high
```

---

## 18. Half Pill — Minimal Smart Desk Pill Reminder with ESP32

**Source:** https://www.youtube.com/watch?v=pdmuOCIE_68

```
name: Half Pill — Minimal Smart Desk Pill Reminder
author: gokux
image: https://i.ytimg.com/vi/pdmuOCIE_68/maxresdefault.jpg
summary_blog: A minimal, aesthetically designed pill reminder device for the desk that uses an ESP32 microcontroller to track and notify users when to take their medication. The "Half Pill" project emphasizes a clean, minimalist form factor suitable for desktop use, with smart scheduling and reminder notifications. Compact and practical for health management.
board: ESP32 (specific model unknown)
category: Healthcare
year: 2026
month: 2
programming_language: null
secondary_languages: null
framework_tool: null
runtime_platform: null
key_tech: Smart Reminders, Health Monitoring
hardware_stack: ESP32, display/notification hardware
use_case: Health / Wellness
source_evidence: YouTube video (gokux)
confidence: medium
```

---

## 19. Hup Smart Camera — AI Home Assistant

**Source:** https://www.hackster.io/hup-technologies/hup-smart-camera-ai-home-assistant-34f8f5

```
name: Hup Smart Camera — AI Home Assistant
author: Hup Technologies
image: null
summary_blog: An AI-powered home camera and assistant product called Hup, described as an "AI Home Assistant That Sees, Thinks & Helps" priced at $120. Hackster project page behind login wall — full content inaccessible without sign-in. The project is a commercial product (not a DIY build).
board: Unknown (commercial product — no DIY project details accessible)
category: Smart Home
year: 2026
month: null
programming_language: null
secondary_languages: null
framework_tool: null
runtime_platform: null
key_tech: AI, Computer Vision, Smart Home
hardware_stack: Camera module (commercial product details unknown)
use_case: Smart Home / AI Assistant
source_evidence: Hackster.io project page (login wall — content inaccessible); withhup.com product page
confidence: low
# NOTE: Commercial product, not a DIY project — should be excluded from DIY candidate pool
```

---

## 20. Control a Sphero RVR with Seeed Studio ESP32S3 over AWS IoT Core

**Source:** https://www.youtube.com/watch?v=WM8tDXyR6oo

```
name: Cloud-Connected Sphero RVR Controller — XIAO ESP32S3 + AWS IoT Core
author: Chiwai Chan
image: https://i.ytimg.com/vi/WM8tDXyR6oo/sd2.jpg
summary_blog: A cloud-connected robotics controller bridging a Sphero RVR programmable robot with AWS IoT Core using the Seeed Studio XIAO ESP32S3 microcontroller. The system connects to Sphero RVR via UART while maintaining Wi-Fi connectivity to AWS, publishing real-time telemetry (IMU, encoders, color sensor, battery, motor temps) to MQTT every 60 seconds. Remote drive commands are accepted via MQTT subscribe. The XIAO Expansion Board provides an OLED display for status info. Supports tank drive, raw motor control, LED commands, and sleep/wake. A comprehensive project demonstrating full-stack IoT robotics.
board: XIAO ESP32-S3
category: Robotics
year: 2026
month: 1
programming_language: C/C++
secondary_languages: null
framework_tool: PlatformIO, Arduino framework
runtime_platform: AWS IoT Core (MQTT)
key_tech: AWS IoT Core, MQTT, Wi-Fi, UART, Robotics, Telemetry
hardware_stack: XIAO ESP32-S3, XIAO Expansion Board (OLED 128x64), Sphero RVR robot, AWS IoT Core
use_case: Cloud Robotics / Remote Control / IoT
source_evidence: YouTube video (Chiwai Chan) + GitHub repo (chiwaichan/platformio-aws-iot-seeed-studio-esp32s3-sphero-rvr)
confidence: high
```

---

## 21. Half Pill — Minimal Smart Desk Pill Reminder (Hackster)

**Source:** https://www.hackster.io/Gokux/half-pill-a-minimal-smart-desk-pill-reminder-34f8f5

```
name: Half Pill — Minimal Smart Desk Pill Reminder
author: Gokul
image: null
summary_blog: A minimal smart Wi-Fi enabled pill reminder desk device built with the Seeed Studio XIAO ESP32-C3 and Seeed Studio Round Display for XIAO. Features a clean, unobtrusive aesthetic designed for the desk. The device notifies users when to take their medication and can be integrated into smart home workflows. Difficulty: Intermediate. Build time: 2 hours. Tags: 3D Printing, Displays, Home Automation, IoT.
board: XIAO ESP32-C3
category: Healthcare
year: 2026
month: 2
programming_language: null
secondary_languages: null
framework_tool: null
runtime_platform: null
key_tech: Wi-Fi, Display, Smart Reminders, 3D Printing
hardware_stack: XIAO ESP32-C3, Seeed Studio Round Display for XIAO, 3D-printed enclosure
use_case: Health / Wellness / Smart Home
source_evidence: Hackster.io project page (limited — content behind login wall, supplemented with title/description)
confidence: medium
```

---

## 22. RobotDuck Head — ESP32-S3 Sense Voice AI Robot

**Source:** https://github.com/AI-FanGe/RobotDuck_Head_Esp32

```
name: RobotDuck Head — XIAO ESP32-S3 Sense Voice AI Robot
author: AI-FanGe
image: https://private-user-images.githubusercontent.com/202376609/531197150-1ac002ed-0f35-4130-b84c-3e189a74cf6a.png (private, not accessible)
summary_blog: A smart voice-interactive robot head with lifelike facial expressions, built around the Seeed Studio XIAO ESP32-S3 Sense board featuring an onboard camera and microphone. Integrates Alibaba Cloud's FunASR for real-time voice recognition and Qwen LLM for conversational AI, plus CosyVoice TTS with voice cloning. Features 16-channel servo control for blinking, eye tracking, and lip synchronization. Includes MediaPipe gesture detection for touch avoidance, a 4-DOF bus servo robotic arm, and a web control interface for real-time camera preview and expression debugging.
board: XIAO ESP32-S3 Sense
category: Robotics
year: 2025
month: null
programming_language: Python, C++
secondary_languages: null
framework_tool: Alibaba Cloud (FunASR, Qwen, CosyVoice), MediaPipe, PlatformIO or Arduino
runtime_platform: null
key_tech: Voice AI, LLMs, TTS, Gesture Detection, Servo Control, Computer Vision
hardware_stack: XIAO ESP32-S3 Sense, PCA9685 servo driver (16 channels), SG90 servos (11 for facial expressions), MAX98357A I2S amplifier, 4-DOF SCServo robotic arm
use_case: AI Companion Robot / Voice Assistant
source_evidence: GitHub README (AI-FanGe/RobotDuck_Head_Esp32)
confidence: high
```

---

## 23. EW26 / Seeed Studio XIAO LinkedIn Update

**Source:** https://www.linkedin.com/feed/update/urn:li:activity:7415857506117201920/

```
name: Seeed Studio XIAO at EW26 Conference
author: Seeed Studio (via LinkedIn)
image: null
summary_blog: A LinkedIn post about Seeed Studio's presence at EW26 (Embedded World 2026), showcasing XIAO series hardware and possibly new product announcements. Details unavailable due to LinkedIn access restrictions.
board: XIAO series
category: null
year: 2026
month: null
programming_language: null
secondary_languages: null
framework_tool: null
runtime_platform: null
key_tech: null
hardware_stack: null
use_case: null
source_evidence: LinkedIn post (content not accessible)
confidence: low
```

---

## 24. Control a Sphero RVR with Seeed Studio ESP32S3 — Blog Post

**Source:** https://www.chiwaichan.co.nz/blog/2026/01/19/sphero-rvr-aws-iot-esp32s3

*(Same project as #20, blog post details)*
```
name: Cloud-Connected Sphero RVR Controller — Blog
author: Chiwai Chan
image: null
summary_blog: Detailed blog post for the cloud-connected Sphero RVR controller project using XIAO ESP32S3 and AWS IoT Core. The blog provides step-by-step instructions for wiring, AWS IoT Core setup (things, certificates, policies), PlatformIO project configuration, certificate management, deploying via deploy.sh script, MQTT topics for telemetry and commands, and troubleshooting tips.
board: XIAO ESP32-S3
category: Robotics
year: 2026
month: 1
programming_language: C++
secondary_languages: null
framework_tool: PlatformIO
runtime_platform: AWS IoT Core (MQTT)
key_tech: AWS IoT Core, MQTT, Wi-Fi, UART, Sphero RVR API
hardware_stack: XIAO ESP32-S3, XIAO Expansion Board, Sphero RVR
use_case: Cloud Robotics / IoT
source_evidence: Blog post (chiwaichan.co.nz)
confidence: high
```

---

## 25. PlatformIO AWS IoT Sphero RVR — GitHub Repo

**Source:** https://github.com/chiwaichan/platformio-aws-iot-seeed-studio-esp32s3-sphero-rvr

*(Same project as #20/#24)*
```
name: Cloud-Connected Sphero RVR — XIAO ESP32S3 + PlatformIO + AWS IoT Core
author: chiwaichan
image: null
summary_blog: A cloud-connected robotics controller bridging a Sphero RVR robot with AWS IoT Core using PlatformIO and the Seeed Studio XIAO ESP32S3. Publishes real-time sensor telemetry (IMU, encoders, color, battery, motor temps, position/velocity) over MQTT every 60 seconds. Accepts remote drive commands (tank drive, raw motors, headlights, LEDs, sleep/wake) via MQTT. Uses XIAO Expansion Board OLED for status display. MIT licensed, with full deployment script and troubleshooting guide.
board: XIAO ESP32-S3
category: Robotics
year: 2026
month: 1
programming_language: C++
secondary_languages: null
framework_tool: PlatformIO, Arduino framework
runtime_platform: AWS IoT Core (MQTT)
key_tech: AWS IoT Core, MQTT, PlatformIO, Wi-Fi, UART, robotics
hardware_stack: XIAO ESP32-S3, XIAO Expansion Board (OLED SSD1306 128x64), Sphero RVR
use_case: Cloud Robotics / Remote Control / IoT
source_evidence: GitHub README
confidence: high
```
